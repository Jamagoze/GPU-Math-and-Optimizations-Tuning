// gpu_math: global Zygisk module. Forces GLES anisotropic filtering off (max anisotropy = 1) and adds
// fast-math flags to OpenCL builds. GOT-patches glTex/SamplerParameter*, eglGetProcAddress, clBuildProgram.
#include <jni.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string>
#include <vector>
#include "zygisk.hpp"

static bool g_af = true, g_cl = true;
static std::vector<std::string> g_excl;

typedef void *(*egpa_t)(const char *);
typedef int (*cbp_t)(void *, unsigned, void *const *, const char *, void (*)(void *, void *), void *);
static egpa_t g_egpa;
static cbp_t g_cbp;

static void *sym_in(const char *lib, const char *name) {
    void *h = dlopen(lib, RTLD_NOW | RTLD_NOLOAD);
    if (!h) h = dlopen(lib, RTLD_NOW);
    void *p = h ? dlsym(h, name) : nullptr;
    if (!p) p = dlsym(RTLD_DEFAULT, name);
    return p;
}

// ---------- anisotropic filtering off ----------
// GL_TEXTURE_MAX_ANISOTROPY_EXT (0x84FE) is clamped to 1.0 on textures and sampler objects.
static const float kf = 1.0f;
static const int ki = 1;
#define AFHOOK(fn, T, FIX)                                                          \
    static void *r_##fn;                                                            \
    static void hook_##fn(unsigned a, unsigned p, T v) {                            \
        void *r = r_##fn ? r_##fn : (r_##fn = sym_in("libGLESv2.so", #fn));         \
        if (!r) return;                                                             \
        if (g_af && p == 0x84FE) v = FIX;                                           \
        ((void (*)(unsigned, unsigned, T))r)(a, p, v);                              \
    }
AFHOOK(glTexParameterf, float, 1.0f)
AFHOOK(glTexParameterfv, const float *, &kf)
AFHOOK(glTexParameteri, int, 1)
AFHOOK(glTexParameteriv, const int *, &ki)
AFHOOK(glSamplerParameterf, float, 1.0f)
AFHOOK(glSamplerParameterfv, const float *, &kf)
AFHOOK(glSamplerParameteri, int, 1)
AFHOOK(glSamplerParameteriv, const int *, &ki)

struct Tgt { const char *n; void *fn; void **real; bool *on; };
#define AFT(n) {#n, (void *)hook_##n, &r_##n, &g_af}

static void *hook_egpa(const char *name);
static int hook_cbp(void *, unsigned, void *const *, const char *, void (*)(void *, void *), void *);
static Tgt g_tgt[] = {
    AFT(glTexParameterf), AFT(glTexParameterfv), AFT(glTexParameteri), AFT(glTexParameteriv),
    AFT(glSamplerParameterf), AFT(glSamplerParameterfv), AFT(glSamplerParameteri), AFT(glSamplerParameteriv),
    {"eglGetProcAddress", (void *)hook_egpa, nullptr, &g_af},
    {"clBuildProgram", (void *)hook_cbp, nullptr, &g_cl},
};

// Engines that fetch GL entry points through EGL get our hooks too.
static void *hook_egpa(const char *name) {
    if (!g_egpa) g_egpa = (egpa_t)sym_in("libEGL.so", "eglGetProcAddress");
    if (!g_egpa) return nullptr;
    void *p = g_egpa(name);
    if (p && name && g_af)
        for (auto &t : g_tgt)
            if (t.real && !strcmp(name, t.n)) { if (!*t.real) *t.real = p; return t.fn; }
    return p;
}

// ---------- OpenCL fast math ----------
static int hook_cbp(void *prog, unsigned nd, void *const *dev, const char *opt, void (*cb)(void *, void *), void *ud) {
    cbp_t real = g_cbp ? g_cbp : (g_cbp = (cbp_t)sym_in("libOpenCL.so", "clBuildProgram"));
    if (!real) return -30;
    if (g_cl && !(opt && strstr(opt, "-cl-fast-relaxed-math"))) {
        std::string o = opt ? opt : "";
        o += " -cl-fast-relaxed-math -cl-mad-enable";
        int r = real(prog, nd, dev, o.c_str(), cb, ud);
        if (r != -43) return r;  // CL_INVALID_BUILD_OPTIONS: retry untouched
    }
    return real(prog, nd, dev, opt, cb, ud);
}

// ---------- GOT patcher ----------
#if defined(__LP64__)
typedef ElfW(Rela) Rel;
#define RSYM(i) ((i) >> 32)
#define RTYPE(i) ((i) & 0xffffffffu)
enum { T_SLOT = 1026, T_GLOB = 1025, T_ABS = 257 };
#else
typedef ElfW(Rel) Rel;
#define RSYM(i) ((i) >> 8)
#define RTYPE(i) ((i) & 0xffu)
enum { T_SLOT = 22, T_GLOB = 21, T_ABS = 2 };
#endif

struct Map { uintptr_t s, e; int prot; };
static void read_maps(std::vector<Map> &v) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return;
    char line[1024];
    while (fgets(line, sizeof line, f)) {
        unsigned long s, e;
        char p[8];
        if (sscanf(line, "%lx-%lx %7s", &s, &e, p) == 3)
            v.push_back({s, e, (p[0] == 'r' ? PROT_READ : 0) | (p[1] == 'w' ? PROT_WRITE : 0) | (p[2] == 'x' ? PROT_EXEC : 0)});
    }
    fclose(f);
}

static void put(std::vector<Map> &m, void **slot, void *fn) {
    if (*slot == fn) return;
    if (m.empty()) read_maps(m);
    static const uintptr_t ps = (uintptr_t)sysconf(_SC_PAGESIZE);
    uintptr_t pg = (uintptr_t)slot & ~(ps - 1);
    int pr = 0;
    for (auto &x : m) if (pg >= x.s && pg < x.e) { pr = x.prot; break; }
    if (!(pr & PROT_READ)) return;
    bool w = pr & PROT_WRITE;
    if (!w && mprotect((void *)pg, ps, pr | PROT_WRITE)) return;
    __atomic_store_n(slot, fn, __ATOMIC_RELAXED);
    if (!w) mprotect((void *)pg, ps, pr);
}

static void scan(uintptr_t bias, const char *str, const ElfW(Sym) *sym, uintptr_t tab, size_t sz, std::vector<Map> &maps) {
    if (!tab || !sz || !str || !sym) return;
    for (size_t o = 0; o + sizeof(Rel) <= sz; o += sizeof(Rel)) {
        const Rel *r = (const Rel *)(tab + o);
        unsigned type = RTYPE(r->r_info);
        if (type != T_SLOT && type != T_GLOB && type != T_ABS) continue;
#if defined(__LP64__)
        if (type == T_ABS && r->r_addend) continue;
#else
        if (type == T_ABS) continue;
#endif
        size_t si = RSYM(r->r_info);
        if (!si || sym[si].st_shndx != SHN_UNDEF) continue;
        const char *nm = str + sym[si].st_name;
        for (auto &t : g_tgt)
            if (*t.on && !strcmp(nm, t.n)) put(maps, (void **)(bias + r->r_offset), t.fn);
    }
}

static int g_marker;
static bool in_self(const dl_phdr_info *i) {
    uintptr_t a = (uintptr_t)&g_marker;
    for (int k = 0; k < i->dlpi_phnum; k++) {
        const ElfW(Phdr) &p = i->dlpi_phdr[k];
        if (p.p_type == PT_LOAD && a >= i->dlpi_addr + p.p_vaddr && a < i->dlpi_addr + p.p_vaddr + p.p_memsz) return true;
    }
    return false;
}
static bool skip_name(const char *n) {
    static const char *k[] = {"/libc.so", "/libdl.so", "linker", "libEGL", "libGLES", "libOpenCL"};
    for (auto s : k) if (strstr(n, s)) return true;
    return false;
}

static int each_lib(dl_phdr_info *i, size_t, void *d) {
    auto &maps = *(std::vector<Map> *)d;
    const char *n = i->dlpi_name;
    if (!n || !*n || skip_name(n) || in_self(i)) return 0;
    const ElfW(Dyn) *dyn = nullptr;
    for (int k = 0; k < i->dlpi_phnum; k++)
        if (i->dlpi_phdr[k].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn) *)(i->dlpi_addr + i->dlpi_phdr[k].p_vaddr); break; }
    if (!dyn) return 0;
    uintptr_t bias = i->dlpi_addr, str = 0, sym = 0, jmp = 0, rel = 0;
    size_t jsz = 0, rsz = 0;
    auto fix = [&](uintptr_t p) { return p < bias ? p + bias : p; };
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_STRTAB: str = fix(dyn->d_un.d_ptr); break;
            case DT_SYMTAB: sym = fix(dyn->d_un.d_ptr); break;
            case DT_JMPREL: jmp = fix(dyn->d_un.d_ptr); break;
            case DT_PLTRELSZ: jsz = dyn->d_un.d_val; break;
#if defined(__LP64__)
            case DT_RELA: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELASZ: rsz = dyn->d_un.d_val; break;
#else
            case DT_REL: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELSZ: rsz = dyn->d_un.d_val; break;
#endif
        }
    }
    // shortcut: packed (APS2/RELR) relocs aren't parsed; PLT slots (DT_JMPREL) cover normal GL calls. upgrade: add sleb128 decoder.
    scan(bias, (const char *)str, (const ElfW(Sym) *)sym, jmp, jsz, maps);
    scan(bias, (const char *)str, (const ElfW(Sym) *)sym, rel, rsz, maps);
    return 0;
}

static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
static void patch_all() {
    if (pthread_mutex_trylock(&g_mu)) return;
    std::vector<Map> maps;
    dl_iterate_phdr(each_lib, &maps);
    pthread_mutex_unlock(&g_mu);
}

static void *poll(void *) {
    for (int i = 0;; i++) {
        usleep(i < 300 ? 500000 : 5000000);
        patch_all();
    }
    return nullptr;
}

// Re-patch right after every System.loadLibrary so game engines are hooked before their first shader.
static jstring (*g_old_load)(JNIEnv *, jclass, jstring, jobject, jobject);
static jstring my_load(JNIEnv *e, jclass c, jstring f, jobject l, jobject x) {
    jstring r = g_old_load(e, c, f, l, x);
    patch_all();
    return r;
}

// ---------- config + module ----------
static void load_cfg(int dfd) {
    g_af = g_cl = true;
    g_excl.clear();
    int fd = dfd >= 0 ? openat(dfd, "config.txt", O_RDONLY) : -1;
    if (fd < 0) return;
    char buf[4096];
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    if (n <= 0) return;
    buf[n] = 0;
    for (char *l = strtok(buf, "\r\n"); l; l = strtok(nullptr, "\r\n")) {
        while (*l == ' ') l++;
        char *v = strchr(l, '=');
        if (*l == '#' || !v) continue;
        *v++ = 0;
        if (!strcmp(l, "af_off")) g_af = atoi(v) != 0;
        else if (!strcmp(l, "opencl")) g_cl = atoi(v) != 0;
        else if (!strcmp(l, "exclude")) {
            char *sp;
            for (char *t = strtok_r(v, " ,", &sp); t; t = strtok_r(nullptr, " ,", &sp)) g_excl.push_back(t);
        }
    }
}

class GpuMath : public zygisk::ModuleBase {
    zygisk::Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
    bool on_ = false;

public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override { api_ = api; env_ = env; }

    void preAppSpecialize(zygisk::AppSpecializeArgs *a) override {
        if (!a->nice_name || !a->app_data_dir) return;  // isolated processes
        const char *nm = env_->GetStringUTFChars(a->nice_name, nullptr);
        if (!nm) return;
        std::string name(nm);
        env_->ReleaseStringUTFChars(a->nice_name, nm);
        // bootanimation is a native binary (never forked from zygote); guard anyway.
        if (name.find("zygote") != std::string::npos || name.find("bootanim") != std::string::npos) return;
        load_cfg(api_->getModuleDir());
        if (!g_af && !g_cl) return;
        std::string pkg = name.substr(0, name.find(':'));
        for (auto &x : g_excl) if (x == pkg) return;
        on_ = true;
        JNINativeMethod m[1] = {{"nativeLoad", "(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/Class;)Ljava/lang/String;", (void *)my_load}};
        api_->hookJniNativeMethods(env_, "java/lang/Runtime", m, 1);
        if (!m[0].fnPtr) {
            m[0] = {"nativeLoad", "(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/lang/String;", (void *)my_load};
            api_->hookJniNativeMethods(env_, "java/lang/Runtime", m, 1);
        }
        g_old_load = (decltype(g_old_load))m[0].fnPtr;
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!on_) { api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY); return; }
        patch_all();
        pthread_t t;
        if (!pthread_create(&t, nullptr, poll, nullptr)) pthread_detach(t);
    }

    void preServerSpecialize(zygisk::ServerSpecializeArgs *) override {
        api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }
};

REGISTER_ZYGISK_MODULE(GpuMath)
