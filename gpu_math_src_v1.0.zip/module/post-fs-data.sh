#!/system/bin/sh
# Bootloop guard: if the previous boot never finished, disable the module.
MODDIR=${0%/*}
F=/data/adb/gpu_math_boot
if [ -f "$F" ]; then
  touch "$MODDIR/disable"
  rm -f "$F"
else
  touch "$F"
fi
