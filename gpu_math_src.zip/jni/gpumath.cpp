// gpu_math: global Zygisk module. GLES texture load reduction (anisotropic off, bilinear mips, nearest, min LOD)
// fragment shader default precision highp->mediump (fp16 math) and OpenCL fast-math build flags.
// v1.4: tex_mip_skip, shadow_skip, render_scale (all default off).
// PBR options (all default off): pbr_fastmath (pow(x,N) -> multiplies), ibl_min_lod (cubemap min LOD), pbr_no_normalmap, pbr_ibl_blur,
// tex_downscale (halve/quarter big RGB/RGBA8 2D textures at upload).
// Event-driven, no polling: libGLESv2/libEGL's export table is rewritten so every library loaded later
// (or still lazily bound) resolves glTex/SamplerParameter* to our hooks; libraries already bound get a one-time GOT patch.
#include <jni.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <algorithm>
#include <string>
#include <unordered_map>
#include <vector>
#include "zygisk.hpp"

static bool g_af = true, g_fp16 = true, g_egl = true, g_cl = true;
static bool g_pbr = false, g_gss = true;   // pbr_fastmath; g_gss = glShaderSource hook needed (fp16 or pbr)
static bool g_nonorm = false;              // pbr_no_normalmap
static int g_iblb = 0;                     // pbr_ibl_blur (extra LOD on cubemap lookups)
static std::string g_nnames = "normal,nrm,bump", g_inames = "env,refl,ibl,irrad,radiance,prefilter,specular";
static int g_ibl = 0;                      // ibl_min_lod
static bool g_dson = false;                // tex_downscale on
static int g_dsh = 0, g_dsmin = 1024;      // downscale shift (1 = /2, 2 = /4), min texture side in px
static bool g_mskip = false;               // tex_mip_skip on
static int g_mssh = 0, g_msmin = 512;      // mip levels to drop, min texture side in px
static bool g_ss = false, g_rs = false;    // shadow_skip, render_scale
static int g_rspct = 100;                  // render_scale percent
static bool g_fbt = false, g_trk = false;  // framebuffer tracking hooks needed, texture-bind tracking hooks needed
static std::vector<std::string> g_excl;


static void *sym_in(const char *lib, const char *name) {
    void *h = dlopen(lib, RTLD_NOW | RTLD_NOLOAD);
    if (!h) h = dlopen(lib, RTLD_NOW);
    void *p = h ? dlsym(h, name) : nullptr;
    if (!p) p = dlsym(RTLD_DEFAULT, name);
    return p;
}

// ---------- texture load reduction ----------
// af_off:        GL_TEXTURE_MAX_ANISOTROPY_EXT (0x84FE) forced to 1.
// mip_bilinear:  MIN_FILTER LINEAR_MIPMAP_LINEAR -> LINEAR_MIPMAP_NEAREST (NEAREST_MIPMAP_LINEAR -> NEAREST_MIPMAP_NEAREST).
// tex_nearest:   MAG/MIN filters LINEAR -> NEAREST, all mipmapped MIN filters -> NEAREST_MIPMAP_NEAREST.
// tex_min_lod:   GL_TEXTURE_MIN_LOD (0x813A) raised to N on textures and samplers (ES 3.x contexts only).
static bool g_bil = false, g_near = false, g_tex = true;
static int g_lod = 0;
static __thread int t_lod;  // MIN_LOD for the call being hooked (g_lod, or g_ibl on cubemaps)
static const float kf = 1.0f;
static const int ki = 1;

static int adj_i(unsigned p, int v) {
    if (g_af && p == 0x84FE) return 1;
    if (g_near) {
        if (p == 0x2800 && v == 0x2601) return 0x2600;
        if (p == 0x2801) {
            if (v == 0x2601) return 0x2600;
            if (v >= 0x2701 && v <= 0x2703) return 0x2700;
        }
    } else if (g_bil && p == 0x2801) {
        if (v == 0x2703) return 0x2701;
        if (v == 0x2702) return 0x2700;
    }
    if (p == 0x813A && t_lod > 0 && v < t_lod) return t_lod;
    return v;
}
static float adj_f(unsigned p, float v) {
    if (p == 0x84FE) return g_af ? 1.0f : v;
    if (p == 0x813A) return (t_lod > 0 && v < t_lod) ? (float)t_lod : v;
    int i = (int)v, j = adj_i(p, i);
    return j == i ? v : (float)j;
}
static bool relevant(unsigned p) { return p == 0x84FE || p == 0x2800 || p == 0x2801 || p == 0x813A; }

static bool es3() {
    static __thread int c;  // 0 unknown, 1 ES3+, 2 ES2
    if (c) return c == 1;
    typedef const unsigned char *(*gs_t)(unsigned);
    gs_t gs = (gs_t)sym_in("libGLESv2.so", "glGetString");
    const char *v = gs ? (const char *)gs(0x1F02) : nullptr;  // GL_VERSION
    if (!v) return false;                                       // no context current: don't cache
    c = strstr(v, "OpenGL ES 3") ? 1 : 2;
    return c == 1;
}
// Sets MIN_LOD right after a MIN_FILTER call, using the real (unhooked) glTex/SamplerParameterf.
static void inj(void **rp, const char *name, void *self, unsigned a) {
    if (!*rp) *rp = sym_in("libGLESv2.so", name);
    if (*rp && *rp != self && es3()) ((void (*)(unsigned, unsigned, float))*rp)(a, 0x813A, (float)t_lod);
}

#define TEXHOOK(fn, T, ADJ, TMP, INJR, INJN, ISTEX)                                          \
    static void *r_##fn;                                                            \
    static void hook_##fn(unsigned a, unsigned p, T v) {                            \
        void *r = r_##fn ? r_##fn : (r_##fn = sym_in("libGLESv2.so", #fn));         \
        if (!r || r == (void *)hook_##fn) return;                                   \
        TMP                                                                         \
        t_lod = (ISTEX && a == 0x8513 && g_ibl > g_lod) ? g_ibl : g_lod;            \
        if (relevant(p)) { ADJ }                                                    \
        ((void (*)(unsigned, unsigned, T))r)(a, p, v);                              \
        if (t_lod > 0 && p == 0x2801) inj(&INJR, INJN, (void *)hook_##fn, a);              \
    }
TEXHOOK(glTexParameterf, float, v = adj_f(p, v);, , r_glTexParameterf, "glTexParameterf", 1)
TEXHOOK(glTexParameterfv, const float *, if (v) { t = adj_f(p, *v); v = &t; }, float t;, r_glTexParameterf, "glTexParameterf", 1)
TEXHOOK(glTexParameteri, int, v = adj_i(p, v);, , r_glTexParameterf, "glTexParameterf", 1)
TEXHOOK(glTexParameteriv, const int *, if (v) { t = adj_i(p, *v); v = &t; }, int t;, r_glTexParameterf, "glTexParameterf", 1)
TEXHOOK(glSamplerParameterf, float, v = adj_f(p, v);, , r_glSamplerParameterf, "glSamplerParameterf", 0)
TEXHOOK(glSamplerParameterfv, const float *, if (v) { t = adj_f(p, *v); v = &t; }, float t;, r_glSamplerParameterf, "glSamplerParameterf", 0)
TEXHOOK(glSamplerParameteri, int, v = adj_i(p, v);, , r_glSamplerParameterf, "glSamplerParameterf", 0)
TEXHOOK(glSamplerParameteriv, const int *, if (v) { t = adj_i(p, *v); v = &t; }, int t;, r_glSamplerParameterf, "glSamplerParameterf", 0)

// ---------- fp16 shader rewrite ----------
static bool isid(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_'; }
static bool isws(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r'; }
static bool word_at(const std::string &s, size_t i, const char *w) {
    size_t l = strlen(w);
    if (i + l > s.size() || s.compare(i, l, w) != 0) return false;
    if (i > 0 && isid(s[i - 1])) return false;
    if (i + l < s.size() && isid(s[i + l])) return false;
    return true;
}
static size_t skipws(const std::string &s, size_t i) { while (i < s.size() && isws(s[i])) i++; return i; }
static bool starts(const std::string &t, const char *p) { return t.compare(0, strlen(p), p) == 0; }
static bool is_float_type(const std::string &t) {
    return t == "float" || t == "vec2" || t == "vec3" || t == "vec4" || starts(t, "mat");
}
static bool is_safe_type(const std::string &t) {
    return t == "highp" || t == "mediump" || t == "lowp" || t == "int" || t == "uint" || t == "bool" ||
           starts(t, "ivec") || starts(t, "uvec") || starts(t, "bvec") || starts(t, "sampler") ||
           starts(t, "isampler") || starts(t, "usampler") || starts(t, "image") || starts(t, "iimage") ||
           starts(t, "uimage");
}
struct Edit { size_t pos, del; const char *ins; };

// Fragment shaders only (no gl_Position). Uniforms are pinned to highp so they still match the vertex shader.
// Shaders with uniform blocks/structs are left untouched (precision must match across stages).
static bool fp16_rewrite(const std::string &s, std::string &out) {
    if (s.find("gl_Position") != std::string::npos || s.find("local_size") != std::string::npos) return false;
    std::vector<Edit> ed;
    bool def = false;
    size_t n = s.size();
    for (size_t i = 0; i < n; i++) {
        char c = s[i];
        if (c == 'p' && word_at(s, i, "precision")) {
            size_t j = skipws(s, i + 9);
            if (j < n && word_at(s, j, "highp")) {
                size_t k = skipws(s, j + 5);
                if (k < n && word_at(s, k, "float")) { ed.push_back({j, 5, "mediump"}); def = true; }
            }
            i += 8;
        } else if (c == 'u' && word_at(s, i, "uniform")) {
            size_t j = skipws(s, i + 7), e = j;
            while (e < n && isid(s[e])) e++;
            std::string t = s.substr(j, e - j);
            if (is_float_type(t)) ed.push_back({j, 0, "highp "});
            else if (!is_safe_type(t)) return false;
            i += 6;
        }
    }
    if (!def) return false;
    out.reserve(n + ed.size() * 8);
    size_t p = 0;
    for (auto &e : ed) { out.append(s, p, e.pos - p); out += e.ins; p = e.pos + e.del; }
    out.append(s, p, std::string::npos);
    return true;
}

// ---------- PBR: pow(x, N) -> multiplies ----------
// pow(x, 2.0|3.0|4.0|5.0|8.0) with a literal exponent becomes a helper call gm_pN(x) (x*x...), which also keeps x evaluated once.
// Helpers are appended on the same line right after the shader's `precision <p> float;` so they inherit its precision and
// line numbers don't move. shortcut: only literal integer exponents, fragment shaders with a float precision statement; upgrade: pow(x, 2.2) gamma.
struct Ed2 { size_t pos, del; std::string ins; };
static const int kPowN[] = {2, 3, 4, 5, 8};
static const char *kPowBody[] = {"return x*x;", "return x*x*x;", "T y=x*x;return y*y;", "T y=x*x;return y*y*x;", "T y=x*x;y=y*y;return y*y;"};

static bool pbr_rewrite(const std::string &s, std::string &out) {
    if (s.find("pow") == std::string::npos) return false;
    if (s.find("gl_Position") != std::string::npos || s.find("local_size") != std::string::npos) return false;
    size_t n = s.size(), ins = std::string::npos;
    for (size_t i = 0; i < n && ins == std::string::npos; i++) {
        if (s[i] != 'p' || !word_at(s, i, "precision")) continue;
        size_t j = skipws(s, i + 9);
        const char *q = word_at(s, j, "highp") ? "highp" : word_at(s, j, "mediump") ? "mediump" : word_at(s, j, "lowp") ? "lowp" : nullptr;
        if (!q) continue;
        size_t k = skipws(s, j + strlen(q));
        if (!word_at(s, k, "float")) continue;
        size_t m = skipws(s, k + 5);
        if (m < n && s[m] == ';') ins = m + 1;
    }
    if (ins == std::string::npos) return false;
    std::vector<Ed2> ed;
    bool used[5] = {};
    for (size_t i = 0; i + 3 < n; i++) {
        if (s[i] != 'p' || !word_at(s, i, "pow") || (i > 0 && s[i - 1] == '.')) continue;
        size_t j = skipws(s, i + 3);
        if (j >= n || s[j] != '(') continue;
        int depth = 0;
        size_t comma = std::string::npos, close = std::string::npos;
        for (size_t k = j + 1; k < n; k++) {
            char c = s[k];
            if (c == '(' || c == '[') depth++;
            else if (c == ')' || c == ']') { if (depth == 0) { close = k; break; } depth--; }
            else if (c == ',' && depth == 0 && comma == std::string::npos) comma = k;
        }
        if (close == std::string::npos || comma == std::string::npos) continue;
        size_t a = skipws(s, comma + 1), b = a;
        while (b < close && s[b] >= '0' && s[b] <= '9') b++;
        if (b == a) continue;
        int num = atoi(s.substr(a, b - a).c_str());
        if (b < close && s[b] == '.') { b++; while (b < close && s[b] == '0') b++; }
        if (b < close && (s[b] == 'f' || s[b] == 'F')) b++;
        if (skipws(s, b) != close) continue;
        for (int x = 0; x < 5; x++)
            if (kPowN[x] == num) {
                used[x] = true;
                ed.push_back({i, 3, std::string("gm_p") + std::to_string(num)});
                ed.push_back({comma, close - comma, ""});
            }
    }
    if (ed.empty()) return false;
    std::string h = " ";
    static const char *ty[] = {"float", "vec2", "vec3", "vec4"};
    for (int x = 0; x < 5; x++) {
        if (!used[x]) continue;
        for (auto t : ty) {
            std::string body = kPowBody[x];
            for (size_t p; (p = body.find('T')) != std::string::npos;) body.replace(p, 1, t);
            h += std::string(t) + " gm_p" + std::to_string(kPowN[x]) + "(" + t + " x){" + body + "} ";
        }
    }
    ed.push_back({ins, 0, h});
    std::stable_sort(ed.begin(), ed.end(), [](const Ed2 &a, const Ed2 &b) { return a.pos < b.pos; });
    out.reserve(n + h.size());
    size_t p = 0;
    for (auto &e : ed) { out.append(s, p, e.pos - p); out += e.ins; p = e.pos + e.del; }
    out.append(s, p, std::string::npos);
    return true;
}

// ---------- PBR: name-based sampler patches ----------
// pbr_no_normalmap: texture()/texture2D()/textureLod() on a sampler2D whose NAME contains one of pbr_normal_names becomes a flat
// normal vec4(0.5,0.5,1.0,1.0). pbr_ibl_blur=N: texture(samplerCube, d) -> textureLod(samplerCube, d, N) and
// textureLod(samplerCube, d, l) -> textureLod(samplerCube, d, (l)+N), only for samplerCube names in pbr_ibl_names (empty = all).
// shortcut: needs readable uniform names (mangled names are skipped), deferred G-buffer samplers named "normal" match too, ES 3.x only
// for the IBL blur, plain `uniform samplerX name;` declarations only; upgrade: per-game name lists in a profile.
static std::string lower(std::string t) { for (auto &c : t) c = (char)tolower((unsigned char)c); return t; }
static bool name_match(const std::string &name, const std::string &list, bool empty_all) {
    std::string n = lower(name), t;
    bool any = false, hit = false;
    for (size_t i = 0; i <= list.size(); i++) {
        char c = i < list.size() ? list[i] : ',';
        if (c == ',' || c == ' ') {
            if (!t.empty()) { any = true; if (n.find(lower(t)) != std::string::npos) hit = true; t.clear(); }
        } else t += c;
    }
    return any ? hit : empty_all;
}

static bool pbr_tex_rewrite(const std::string &s, std::string &out) {
    if (s.find("gl_Position") != std::string::npos || s.find("local_size") != std::string::npos) return false;
    bool es3 = s.find("#version 3") != std::string::npos;
    bool doN = g_nonorm, doI = g_iblb > 0 && es3;
    if (!doN && !doI) return false;
    size_t n = s.size();
    std::vector<std::string> norm, cube;
    for (size_t i = 0; i + 7 < n; i++) {
        if (s[i] != 'u' || !word_at(s, i, "uniform")) continue;
        size_t j = i + 7;
        std::string ty;
        for (;;) {  // qualifiers, then the type
            j = skipws(s, j);
            if (j >= n) break;
            if (word_at(s, j, "layout")) { size_t k = s.find(')', j); if (k == std::string::npos) break; j = k + 1; continue; }
            size_t k = j;
            while (k < n && isid(s[k])) k++;
            if (k == j) break;
            std::string w = s.substr(j, k - j);
            j = k;
            if (w == "highp" || w == "mediump" || w == "lowp") continue;
            ty = w;
            break;
        }
        if (ty != "sampler2D" && ty != "samplerCube") continue;
        size_t e = s.find(';', j);
        if (e == std::string::npos) continue;
        std::string nm;
        for (size_t k = j; k <= e; k++) {
            char c = s[k];
            if (isid(c)) nm += c;
            else {
                if (!nm.empty()) {
                    if (ty == "sampler2D" && name_match(nm, g_nnames, false)) norm.push_back(nm);
                    if (ty == "samplerCube" && name_match(nm, g_inames, true)) cube.push_back(nm);
                    nm.clear();
                }
                if (c == '[') { while (k < e && s[k] != ']') k++; }
            }
        }
    }
    auto has = [](const std::vector<std::string> &v, const std::string &x) { return std::find(v.begin(), v.end(), x) != v.end(); };
    std::vector<Ed2> ed;
    for (size_t i = 0; i + 7 < n; i++) {
        if (s[i] != 't' || (i > 0 && s[i - 1] == '.')) continue;
        size_t fl = 0;
        bool lod = false;
        if (word_at(s, i, "texture")) fl = 7;
        else if (word_at(s, i, "texture2D")) fl = 9;
        else if (word_at(s, i, "textureLod")) { fl = 10; lod = true; }
        else continue;
        size_t j = skipws(s, i + fl);
        if (j >= n || s[j] != '(') continue;
        int depth = 0;
        size_t c1 = std::string::npos, c2 = std::string::npos, close = std::string::npos;
        for (size_t k = j + 1; k < n; k++) {
            char c = s[k];
            if (c == '(' || c == '[') depth++;
            else if (c == ')' || c == ']') { if (depth == 0) { close = k; break; } depth--; }
            else if (c == ',' && depth == 0) { if (c1 == std::string::npos) c1 = k; else if (c2 == std::string::npos) c2 = k; }
        }
        if (close == std::string::npos || c1 == std::string::npos) continue;
        size_t a = skipws(s, j + 1), b = c1;
        while (b > a && isws(s[b - 1])) b--;
        std::string arg = s.substr(a, b - a);
        if (doN && has(norm, arg)) {
            ed.push_back({i, close + 1 - i, "vec4(0.5,0.5,1.0,1.0)"});
            i = close;
            continue;
        }
        if (doI && has(cube, arg)) {
            std::string L = std::to_string(g_iblb) + ".0";
            if (!lod && c2 == std::string::npos && fl == 7) {
                ed.push_back({i, 7, "textureLod"});
                ed.push_back({close, 0, "," + L});
            } else if (lod && c2 != std::string::npos) {
                ed.push_back({skipws(s, c2 + 1), 0, "("});
                ed.push_back({close, 0, ")+" + L});
            }
        }
    }
    if (ed.empty()) return false;
    std::stable_sort(ed.begin(), ed.end(), [](const Ed2 &a, const Ed2 &b) { return a.pos < b.pos; });
    out.reserve(n + 64);
    size_t p = 0;
    for (auto &e : ed) { out.append(s, p, e.pos - p); out += e.ins; p = e.pos + e.del; }
    out.append(s, p, std::string::npos);
    return true;
}

static void *r_gss;
static void hook_gss(unsigned sh, int n, const char *const *str, const int *len) {
    typedef void (*gss_t)(unsigned, int, const char *const *, const int *);
    gss_t real = (gss_t)(r_gss ? r_gss : (r_gss = sym_in("libGLESv2.so", "glShaderSource")));
    if (!real || real == (gss_t)hook_gss) return;
    if ((g_fp16 || g_pbr || g_nonorm || g_iblb > 0) && n > 0 && str) {
        std::string cur, tmp;
        bool ch = false;
        for (int i = 0; i < n; i++) {
            if (!str[i]) continue;
            if (len && len[i] >= 0) cur.append(str[i], len[i]); else cur.append(str[i]);
        }
        if (g_fp16 && fp16_rewrite(cur, tmp)) { cur.swap(tmp); tmp.clear(); ch = true; }
        if (g_pbr && pbr_rewrite(cur, tmp)) { cur.swap(tmp); tmp.clear(); ch = true; }
        if ((g_nonorm || g_iblb > 0) && pbr_tex_rewrite(cur, tmp)) { cur.swap(tmp); ch = true; }
        if (ch) {
            const char *p = cur.c_str();
            int l = (int)cur.size();
            real(sh, 1, &p, &l);
            return;
        }
    }
    real(sh, n, str, len);
}

// ---------- PBR: texture downscale at upload ----------
// Big RGB/RGBA8 2D textures uploaded through glTexImage2D with client memory are box-filtered by 2 (or 4) before upload.
// The texture is remembered as "scaled": pre-made mip levels shift down (level L -> L-s) and sub-uploads are scaled to match.
// shortcut: no compressed/glTexStorage2D/PBO/RT textures, sub-uploads not aligned to the factor are dropped, texelFetch/pixel-coord
// shaders see the smaller size, bound-texture state is tracked per thread; upgrade: per-context state + compressed mip skip.
static __thread unsigned t_tex[32];
static __thread int t_unit;
static __thread bool t_pbo;
static __thread int t_align = 4, t_rowlen, t_skipx, t_skipy;
static pthread_mutex_t g_dsmu = PTHREAD_MUTEX_INITIALIZER;
static std::unordered_map<unsigned, int> g_scaled;
static int ds_get(unsigned id) {
    if (!id) return 0;
    pthread_mutex_lock(&g_dsmu);
    auto it = g_scaled.find(id);
    int r = it == g_scaled.end() ? 0 : it->second;
    pthread_mutex_unlock(&g_dsmu);
    return r;
}
static void ds_set(unsigned id, int sh) {
    if (!id) return;
    pthread_mutex_lock(&g_dsmu);
    if (sh) g_scaled[id] = sh; else g_scaled.erase(id);
    pthread_mutex_unlock(&g_dsmu);
}
// textures allocated with their top mip levels left out (tex_mip_skip): id -> number of dropped levels
static std::unordered_map<unsigned, int> g_ms;
static int ms_get(unsigned id) {
    if (!id) return 0;
    pthread_mutex_lock(&g_dsmu);
    auto it = g_ms.find(id);
    int r = it == g_ms.end() ? 0 : it->second;
    pthread_mutex_unlock(&g_dsmu);
    return r;
}
static void ms_set(unsigned id, int sh) {
    if (!id) return;
    pthread_mutex_lock(&g_dsmu);
    if (sh) g_ms[id] = sh; else g_ms.erase(id);
    pthread_mutex_unlock(&g_dsmu);
}

static void *r_gps;
static void hook_gps(unsigned pn, int v) {
    typedef void (*fn_t)(unsigned, int);
    fn_t real = (fn_t)(r_gps ? r_gps : (r_gps = sym_in("libGLESv2.so", "glPixelStorei")));
    if (!real || real == (fn_t)hook_gps) return;
    switch (pn) {
        case 0x0CF5: t_align = v; break;
        case 0x0CF2: t_rowlen = v; break;
        case 0x0CF4: t_skipx = v; break;
        case 0x0CF3: t_skipy = v; break;
    }
    real(pn, v);
}
static void ps(unsigned pn, int v) {
    if (!r_gps) r_gps = sym_in("libGLESv2.so", "glPixelStorei");
    if (r_gps && r_gps != (void *)hook_gps) ((void (*)(unsigned, int))r_gps)(pn, v);
}
static void ps_push() { ps(0x0CF5, 1); if (t_rowlen) ps(0x0CF2, 0); if (t_skipx) ps(0x0CF4, 0); if (t_skipy) ps(0x0CF3, 0); }
static void ps_pop() { ps(0x0CF5, t_align); if (t_rowlen) ps(0x0CF2, t_rowlen); if (t_skipx) ps(0x0CF4, t_skipx); if (t_skipy) ps(0x0CF3, t_skipy); }

static int fmt_bpp(unsigned f) { return f == 0x1908 ? 4 : f == 0x1907 ? 3 : 0; }
static bool ifmt_ok(int f) { return f == 0x1907 || f == 0x1908 || f == 0x8051 || f == 0x8058 || f == 0x8C41 || f == 0x8C43; }

// Box filter of a w*h image (app unpack state applied) down by 1<<sh into a tight buffer.
static void box(const uint8_t *p, int w, int h, int bpp, int sh, std::vector<uint8_t> &o) {
    int f = 1 << sh, ow = w >> sh, oh = h >> sh;
    size_t rl = t_rowlen > 0 ? (size_t)t_rowlen : (size_t)w;
    size_t al = t_align > 0 ? (size_t)t_align : 4;
    size_t stride = (rl * bpp + al - 1) / al * al;
    const uint8_t *base = p + (size_t)t_skipy * stride + (size_t)t_skipx * bpp;
    o.resize((size_t)ow * oh * bpp);
    uint8_t *d = o.data();
    unsigned bits = 2 * sh;
    for (int y = 0; y < oh; y++)
        for (int x = 0; x < ow; x++)
            for (int c = 0; c < bpp; c++) {
                unsigned sum = 0;
                for (int dy = 0; dy < f; dy++) {
                    const uint8_t *q = base + (size_t)(y * f + dy) * stride + (size_t)x * f * bpp + c;
                    for (int dx = 0; dx < f; dx++) sum += q[dx * bpp];
                }
                *d++ = (uint8_t)((sum + (1u << (bits - 1))) >> bits);
            }
}

static void *r_gti2d;
static void hook_gti2d(unsigned tg, int lv, int ifmt, int w, int h, int b, unsigned fmt, unsigned ty, const void *px) {
    typedef void (*fn_t)(unsigned, int, int, int, int, int, unsigned, unsigned, const void *);
    fn_t real = (fn_t)(r_gti2d ? r_gti2d : (r_gti2d = sym_in("libGLESv2.so", "glTexImage2D")));
    if (!real || real == (fn_t)hook_gti2d) return;
    if (g_dson && tg == 0x0DE1) {
        unsigned id = t_tex[t_unit];
        int s = g_dsh, m = (1 << s) - 1, bpp = fmt_bpp(fmt);
        if (lv == 0) {
            bool ok = id && px && !t_pbo && b == 0 && ty == 0x1401 && bpp && ifmt_ok(ifmt) && w >= g_dsmin && h >= g_dsmin && !(w & m) && !(h & m);
            ds_set(id, ok ? s : 0);
            if (ok) {
                std::vector<uint8_t> o;
                box((const uint8_t *)px, w, h, bpp, s, o);
                ps_push();
                real(tg, 0, ifmt, w >> s, h >> s, 0, fmt, ty, o.data());
                ps_pop();
                return;
            }
        } else if (int sc = ds_get(id)) {
            if (lv < sc) return;
            lv -= sc;
        }
    }
    real(tg, lv, ifmt, w, h, b, fmt, ty, px);
}

static void *r_gtsi2d;
static void hook_gtsi2d(unsigned tg, int lv, int x, int y, int w, int h, unsigned fmt, unsigned ty, const void *px) {
    typedef void (*fn_t)(unsigned, int, int, int, int, int, unsigned, unsigned, const void *);
    fn_t real = (fn_t)(r_gtsi2d ? r_gtsi2d : (r_gtsi2d = sym_in("libGLESv2.so", "glTexSubImage2D")));
    if (!real || real == (fn_t)hook_gtsi2d) return;
    if (g_dson && tg == 0x0DE1) {
        int s = ds_get(t_tex[t_unit]);
        if (s) {
            if (lv == 0) {
                int m = (1 << s) - 1, bpp = fmt_bpp(fmt);
                if (px && !t_pbo && ty == 0x1401 && bpp && !((x | y | w | h) & m)) {
                    std::vector<uint8_t> o;
                    box((const uint8_t *)px, w, h, bpp, s, o);
                    ps_push();
                    real(tg, 0, x >> s, y >> s, w >> s, h >> s, fmt, ty, o.data());
                    ps_pop();
                }
                return;
            }
            if (lv < s) return;
            lv -= s;
        }
    }
    real(tg, lv, x, y, w, h, fmt, ty, px);
}

static void *r_gbt, *r_gat, *r_gbb, *r_gdt;
static void hook_gbt(unsigned tg, unsigned id) {
    typedef void (*fn_t)(unsigned, unsigned);
    fn_t real = (fn_t)(r_gbt ? r_gbt : (r_gbt = sym_in("libGLESv2.so", "glBindTexture")));
    if (!real || real == (fn_t)hook_gbt) return;
    if (tg == 0x0DE1) t_tex[t_unit] = id;
    real(tg, id);
}
static void hook_gat(unsigned unit) {
    typedef void (*fn_t)(unsigned);
    fn_t real = (fn_t)(r_gat ? r_gat : (r_gat = sym_in("libGLESv2.so", "glActiveTexture")));
    if (!real || real == (fn_t)hook_gat) return;
    int u = (int)unit - 0x84C0;
    t_unit = (u >= 0 && u < 32) ? u : 0;
    real(unit);
}
static void hook_gbb(unsigned tg, unsigned id) {
    typedef void (*fn_t)(unsigned, unsigned);
    fn_t real = (fn_t)(r_gbb ? r_gbb : (r_gbb = sym_in("libGLESv2.so", "glBindBuffer")));
    if (!real || real == (fn_t)hook_gbb) return;
    if (tg == 0x88EC) t_pbo = id != 0;  // GL_PIXEL_UNPACK_BUFFER
    real(tg, id);
}
static void hook_gdt(int n, const unsigned *ids) {
    typedef void (*fn_t)(int, const unsigned *);
    fn_t real = (fn_t)(r_gdt ? r_gdt : (r_gdt = sym_in("libGLESv2.so", "glDeleteTextures")));
    if (!real || real == (fn_t)hook_gdt) return;
    if (ids) for (int i = 0; i < n; i++) { ds_set(ids[i], 0); ms_set(ids[i], 0); }
    real(n, ids);
}

// ---------- PBR: skip the top mip levels of big compressed textures ----------
// tex_mip_skip=N: glTexStorage2D / glCompressedTexImage2D of an ASTC/ETC2/ETC1/S3TC 2D texture with both sides >= tex_mip_skip_min
// is allocated N levels smaller; uploads of the dropped levels are discarded and the others shift down (level L -> L-N), so the
// biggest mip never reaches the GPU. Needs no resampling and works for compressed + immutable textures that tex_downscale can't touch.
// shortcut: level 0 must be uploaded first for glCompressedTexImage2D textures, BASE_LEVEL > levels-N-1 on immutable textures errors,
// bound-texture state is per thread; upgrade: per-context state.
static bool ifmt_comp(int f) {
    return (f >= 0x93B0 && f <= 0x93BD) || (f >= 0x93D0 && f <= 0x93DD) || (f >= 0x9270 && f <= 0x9279) || f == 0x8D64 || (f >= 0x83F0 && f <= 0x83F3);
}

static void *r_gts2d;
static void hook_gts2d(unsigned tg, int lv, int ifmt, int w, int h) {
    typedef void (*fn_t)(unsigned, int, int, int, int);
    fn_t real = (fn_t)(r_gts2d ? r_gts2d : (r_gts2d = sym_in("libGLESv2.so", "glTexStorage2D")));
    if (!real || real == (fn_t)hook_gts2d) return;
    if (g_mskip && tg == 0x0DE1) {
        unsigned id = t_tex[t_unit];
        int s = g_mssh;
        bool ok = id && ifmt_comp(ifmt) && w >= g_msmin && h >= g_msmin && lv > s;
        ms_set(id, ok ? s : 0);
        if (ok) { real(tg, lv - s, ifmt, w >> s, h >> s); return; }
    }
    real(tg, lv, ifmt, w, h);
}

static void *r_gcti2d;
static void hook_gcti2d(unsigned tg, int lv, int ifmt, int w, int h, int b, int sz, const void *px) {
    typedef void (*fn_t)(unsigned, int, int, int, int, int, int, const void *);
    fn_t real = (fn_t)(r_gcti2d ? r_gcti2d : (r_gcti2d = sym_in("libGLESv2.so", "glCompressedTexImage2D")));
    if (!real || real == (fn_t)hook_gcti2d) return;
    if (g_mskip && tg == 0x0DE1) {
        unsigned id = t_tex[t_unit];
        if (lv == 0) {
            bool ok = id && ifmt_comp(ifmt) && w >= g_msmin && h >= g_msmin && b == 0;
            ms_set(id, ok ? g_mssh : 0);
            if (ok) return;
        } else if (int sc = ms_get(id)) {
            if (lv < sc) return;
            lv -= sc;
        }
    }
    real(tg, lv, ifmt, w, h, b, sz, px);
}

static void *r_gctsi2d;
static void hook_gctsi2d(unsigned tg, int lv, int x, int y, int w, int h, unsigned fmt, int sz, const void *px) {
    typedef void (*fn_t)(unsigned, int, int, int, int, int, unsigned, int, const void *);
    fn_t real = (fn_t)(r_gctsi2d ? r_gctsi2d : (r_gctsi2d = sym_in("libGLESv2.so", "glCompressedTexSubImage2D")));
    if (!real || real == (fn_t)hook_gctsi2d) return;
    if (g_mskip && tg == 0x0DE1) {
        int sc = ms_get(t_tex[t_unit]);
        if (sc) {
            if (lv < sc) return;
            lv -= sc;
        }
    }
    real(tg, lv, x, y, w, h, fmt, sz, px);
}

// ---------- shadow_skip + render_scale: framebuffer tracking ----------
// shadow_skip: draws are dropped while the bound framebuffer has a depth attachment, no color attachment and the app's viewport is
// square (>= 256) - that is a shadow map pass, so shadows stay "lit". A depth prepass has a screen-shaped viewport and is not touched.
// render_scale=P: the game's default framebuffer is replaced by an offscreen one at P% size per EGL context (created at the first
// swap), glViewport/glScissor/glBlitFramebuffer coordinates are scaled while it is bound, and eglSwapBuffers first blits it up to the
// window with linear filtering. glGetIntegerv(FRAMEBUFFER_BINDING / VIEWPORT) report the unscaled values to the app.
// shortcut: ES 3.x contexts only, no MSAA, glReadPixels of the screen returns the small image, framebuffer ids are global (not per
// context), attachments-only depth-only test; upgrade: glInvalidateSubFramebuffer scaling, per-context FBO table.
struct RS { unsigned fbo = 0, rbc = 0, rbd = 0; int W = 0, H = 0, w = 0, h = 0; bool es3 = false, chk = false, bound = false; };
static pthread_mutex_t g_rsmu = PTHREAD_MUTEX_INITIALIZER;
static std::unordered_map<void *, RS> g_rsmap;
static std::unordered_map<unsigned, int> g_fbi;  // framebuffer id -> bit0 depth attached, bit1 color attached
static __thread RS *t_rs;
static __thread void *t_ctx;
static __thread unsigned t_fbo, t_rfbo;  // what the app thinks is bound (0 = default framebuffer)
static __thread int t_vp[4], t_sc[4];    // the app's own viewport / scissor box
static __thread bool t_sk;

static void *real_in(const char *lib, void **r, const char *n, void *hook) {
    if (!*r) *r = sym_in(lib, n);
    return *r == hook ? nullptr : *r;
}
static void *gl_fn(const char *n) { return sym_in("libGLESv2.so", n); }
static inline bool red() { return g_rs && t_rs && t_rs->bound && t_fbo == 0; }
static inline bool redr() { return g_rs && t_rs && t_rs->bound && t_rfbo == 0; }
static int sp(int v, int a, int b) { return (int)((long long)v * a / b); }
static int sl(int v, int a, int b) { return (int)(((long long)v * a + b - 1) / b); }

static void hook_gbf(unsigned, unsigned);
static void hook_gvp(int, int, int, int);
static void hook_gsc(int, int, int, int);
static void hook_gfr(unsigned, unsigned, unsigned, unsigned);
static void hook_gblit(int, int, int, int, int, int, int, int, unsigned, unsigned);
static void hook_ggi(unsigned, int *);
static void *r_gbf, *r_gvp, *r_gsc, *r_gfr, *r_gblit, *r_ggi, *r_gft2d, *r_gftl, *r_gdf;

static void rbind(unsigned t, unsigned id) {
    typedef void (*f_t)(unsigned, unsigned);
    f_t f = (f_t)real_in("libGLESv2.so", &r_gbf, "glBindFramebuffer", (void *)hook_gbf);
    if (f) f(t, id);
}
// Set the real viewport/scissor from the app's boxes, scaled or not.
static void vp_set(bool scaled) {
    typedef void (*f_t)(int, int, int, int);
    f_t fv = (f_t)real_in("libGLESv2.so", &r_gvp, "glViewport", (void *)hook_gvp);
    f_t fs = (f_t)real_in("libGLESv2.so", &r_gsc, "glScissor", (void *)hook_gsc);
    RS *r = t_rs;
    int v[4], c[4];
    for (int i = 0; i < 4; i++) { v[i] = t_vp[i]; c[i] = t_sc[i]; }
    if (r && !v[2] && !v[3]) { v[0] = v[1] = 0; v[2] = r->W; v[3] = r->H; }
    if (r && !c[2] && !c[3]) { c[0] = c[1] = 0; c[2] = r->W; c[3] = r->H; }
    if (scaled && r) {
        int *b[2] = {v, c};
        for (auto q : b) { q[0] = sp(q[0], r->w, r->W); q[1] = sp(q[1], r->h, r->H); q[2] = sl(q[2], r->w, r->W); q[3] = sl(q[3], r->h, r->H); }
    }
    if (fv) fv(v[0], v[1], v[2], v[3]);
    if (fs) fs(c[0], c[1], c[2], c[3]);
}

static void fbi_upd(unsigned fb, unsigned att, bool on) {
    int bit = (att == 0x8D00 || att == 0x821A) ? 1 : (att >= 0x8CE0 && att <= 0x8CEF) ? 2 : 0;
    if (!bit || !fb) return;
    pthread_mutex_lock(&g_rsmu);
    int &v = g_fbi[fb];
    if (on) v |= bit; else v &= ~bit;
    pthread_mutex_unlock(&g_rsmu);
}
static bool fb_depth_only(unsigned fb) {
    if (!fb) return false;
    pthread_mutex_lock(&g_rsmu);
    auto it = g_fbi.find(fb);
    bool r = it != g_fbi.end() && (it->second & 3) == 1;
    pthread_mutex_unlock(&g_rsmu);
    return r;
}

static void hook_gbf(unsigned tg, unsigned id) {
    typedef void (*f_t)(unsigned, unsigned);
    f_t real = (f_t)real_in("libGLESv2.so", &r_gbf, "glBindFramebuffer", (void *)hook_gbf);
    if (!real) return;
    bool d = tg == 0x8D40 || tg == 0x8CA9, rd = tg == 0x8D40 || tg == 0x8CA8;
    bool was = red();
    if (d) t_fbo = id;
    if (rd) t_rfbo = id;
    unsigned eff = (id == 0 && g_rs && t_rs && t_rs->bound) ? t_rs->fbo : id;
    real(tg, eff);
    if (d) {
        if (g_ss) t_sk = fb_depth_only(id);
        if (red() != was) vp_set(red());
    }
}

static void hook_gvp(int x, int y, int w, int h) {
    typedef void (*f_t)(int, int, int, int);
    f_t real = (f_t)real_in("libGLESv2.so", &r_gvp, "glViewport", (void *)hook_gvp);
    if (!real) return;
    t_vp[0] = x; t_vp[1] = y; t_vp[2] = w; t_vp[3] = h;
    if (red()) real(sp(x, t_rs->w, t_rs->W), sp(y, t_rs->h, t_rs->H), sl(w, t_rs->w, t_rs->W), sl(h, t_rs->h, t_rs->H));
    else real(x, y, w, h);
}
static void hook_gsc(int x, int y, int w, int h) {
    typedef void (*f_t)(int, int, int, int);
    f_t real = (f_t)real_in("libGLESv2.so", &r_gsc, "glScissor", (void *)hook_gsc);
    if (!real) return;
    t_sc[0] = x; t_sc[1] = y; t_sc[2] = w; t_sc[3] = h;
    if (red()) real(sp(x, t_rs->w, t_rs->W), sp(y, t_rs->h, t_rs->H), sl(w, t_rs->w, t_rs->W), sl(h, t_rs->h, t_rs->H));
    else real(x, y, w, h);
}

static void hook_gft2d(unsigned tg, unsigned att, unsigned tt, unsigned tex, int lv) {
    typedef void (*f_t)(unsigned, unsigned, unsigned, unsigned, int);
    f_t real = (f_t)real_in("libGLESv2.so", &r_gft2d, "glFramebufferTexture2D", (void *)hook_gft2d);
    if (!real) return;
    if (g_fbt && (tg == 0x8D40 || tg == 0x8CA9)) { fbi_upd(t_fbo, att, tex != 0); if (g_ss) t_sk = fb_depth_only(t_fbo); }
    real(tg, att, tt, tex, lv);
}
static void hook_gftl(unsigned tg, unsigned att, unsigned tex, int lv, int layer) {
    typedef void (*f_t)(unsigned, unsigned, unsigned, int, int);
    f_t real = (f_t)real_in("libGLESv2.so", &r_gftl, "glFramebufferTextureLayer", (void *)hook_gftl);
    if (!real) return;
    if (g_fbt && (tg == 0x8D40 || tg == 0x8CA9)) { fbi_upd(t_fbo, att, tex != 0); if (g_ss) t_sk = fb_depth_only(t_fbo); }
    real(tg, att, tex, lv, layer);
}
static void hook_gfr(unsigned tg, unsigned att, unsigned rt, unsigned rb) {
    typedef void (*f_t)(unsigned, unsigned, unsigned, unsigned);
    f_t real = (f_t)real_in("libGLESv2.so", &r_gfr, "glFramebufferRenderbuffer", (void *)hook_gfr);
    if (!real) return;
    if (g_fbt && (tg == 0x8D40 || tg == 0x8CA9)) { fbi_upd(t_fbo, att, rb != 0); if (g_ss) t_sk = fb_depth_only(t_fbo); }
    real(tg, att, rt, rb);
}
static void hook_gdf(int n, const unsigned *ids) {
    typedef void (*f_t)(int, const unsigned *);
    f_t real = (f_t)real_in("libGLESv2.so", &r_gdf, "glDeleteFramebuffers", (void *)hook_gdf);
    if (!real) return;
    if (ids) { pthread_mutex_lock(&g_rsmu); for (int i = 0; i < n; i++) g_fbi.erase(ids[i]); pthread_mutex_unlock(&g_rsmu); }
    real(n, ids);
}

#define DRAWHOOK(NAME, SIG, ARGS)                                                              \
    static void *r_##NAME;                                                                     \
    static void hook_##NAME SIG {                                                              \
        typedef void(*f_t) SIG;                                                                \
        f_t real = (f_t)real_in("libGLESv2.so", &r_##NAME, #NAME, (void *)hook_##NAME);        \
        if (!real) return;                                                                     \
        if (t_sk && t_vp[2] >= 256 && t_vp[2] == t_vp[3]) return;                              \
        real ARGS;                                                                             \
    }
DRAWHOOK(glDrawArrays, (unsigned m, int f, int c), (m, f, c))
DRAWHOOK(glDrawElements, (unsigned m, int c, unsigned t, const void *i), (m, c, t, i))
DRAWHOOK(glDrawArraysInstanced, (unsigned m, int f, int c, int n), (m, f, c, n))
DRAWHOOK(glDrawElementsInstanced, (unsigned m, int c, unsigned t, const void *i, int n), (m, c, t, i, n))
DRAWHOOK(glDrawRangeElements, (unsigned m, unsigned s0, unsigned e0, int c, unsigned t, const void *i), (m, s0, e0, c, t, i))

// glInvalidateFramebuffer / glDiscardFramebufferEXT use GL_COLOR/GL_DEPTH/GL_STENCIL for the default framebuffer, which our
// offscreen framebuffer does not accept: translate them while it is bound.
#define INVHOOK(NAME, R)                                                                         \
    static void *R;                                                                              \
    static void hook_##NAME(unsigned tg, int n, const unsigned *a) {                             \
        typedef void (*f_t)(unsigned, int, const unsigned *);                                    \
        f_t real = (f_t)real_in("libGLESv2.so", &R, #NAME, (void *)hook_##NAME);                 \
        if (!real) return;                                                                       \
        if (a && n > 0 && n <= 16 && red() && (tg == 0x8D40 || tg == 0x8CA9)) {                  \
            unsigned b[16];                                                                      \
            for (int i = 0; i < n; i++) b[i] = a[i] == 0x1800 ? 0x8CE0 : a[i] == 0x1801 ? 0x8D00 : a[i] == 0x1802 ? 0x8D20 : a[i]; \
            real(tg, n, b);                                                                      \
            return;                                                                              \
        }                                                                                        \
        real(tg, n, a);                                                                          \
    }
INVHOOK(glInvalidateFramebuffer, r_ginv)
INVHOOK(glDiscardFramebufferEXT, r_gdisc)

static void hook_gblit(int sx0, int sy0, int sx1, int sy1, int dx0, int dy0, int dx1, int dy1, unsigned mask, unsigned filt) {
    typedef void (*f_t)(int, int, int, int, int, int, int, int, unsigned, unsigned);
    f_t real = (f_t)real_in("libGLESv2.so", &r_gblit, "glBlitFramebuffer", (void *)hook_gblit);
    if (!real) return;
    if (red()) { dx0 = sp(dx0, t_rs->w, t_rs->W); dx1 = sp(dx1, t_rs->w, t_rs->W); dy0 = sp(dy0, t_rs->h, t_rs->H); dy1 = sp(dy1, t_rs->h, t_rs->H); }
    if (redr()) { sx0 = sp(sx0, t_rs->w, t_rs->W); sx1 = sp(sx1, t_rs->w, t_rs->W); sy0 = sp(sy0, t_rs->h, t_rs->H); sy1 = sp(sy1, t_rs->h, t_rs->H); }
    real(sx0, sy0, sx1, sy1, dx0, dy0, dx1, dy1, mask, filt);
}

static void hook_ggi(unsigned pn, int *v) {
    typedef void (*f_t)(unsigned, int *);
    f_t real = (f_t)real_in("libGLESv2.so", &r_ggi, "glGetIntegerv", (void *)hook_ggi);
    if (!real) return;
    real(pn, v);
    if (!v || !t_rs || !t_rs->bound) return;
    if (pn == 0x8CA6 && t_fbo == 0 && *v == (int)t_rs->fbo) *v = 0;
    else if (pn == 0x8CAA && t_rfbo == 0 && *v == (int)t_rs->fbo) *v = 0;
    else if (pn == 0x0BA2 && red()) {
        if (t_vp[2] || t_vp[3]) for (int i = 0; i < 4; i++) v[i] = t_vp[i];
        else { v[0] = v[1] = 0; v[2] = t_rs->W; v[3] = t_rs->H; }
    }
}

// ---- EGL side of render_scale ----
static void *r_esb, *r_esbk, *r_esbe, *r_emc, *r_edc;
static unsigned hook_esb(void *, void *);
static unsigned hook_esbd(void *, void *, int *, int);
static void *egl_q(const char *n) { return sym_in("libEGL.so", n); }

static void rs_pre(void *dpy, void *surf) {
    typedef void *(*gc_t)();
    typedef unsigned (*qs_t)(void *, void *, int, int *);
    typedef const unsigned char *(*gs_t)(unsigned);
    typedef void (*gen_t)(int, unsigned *);
    typedef void (*bind_t)(unsigned, unsigned);
    typedef void (*rbs_t)(unsigned, unsigned, int, int);
    typedef void (*fr_t)(unsigned, unsigned, unsigned, unsigned);
    typedef void (*geti_t)(unsigned, int *);
    typedef unsigned char (*isen_t)(unsigned);
    typedef void (*en_t)(unsigned);
    typedef void (*blit_t)(int, int, int, int, int, int, int, int, unsigned, unsigned);
    static gc_t gc = (gc_t)egl_q("eglGetCurrentContext");
    static qs_t qs = (qs_t)egl_q("eglQuerySurface");
    if (!gc || !qs) return;
    void *ctx = gc();
    if (!ctx) return;
    if (!t_rs || t_ctx != ctx) {
        pthread_mutex_lock(&g_rsmu);
        t_rs = &g_rsmap[ctx];
        t_ctx = ctx;
        pthread_mutex_unlock(&g_rsmu);
    }
    RS *r = t_rs;
    int W = 0, H = 0;
    if (!qs(dpy, surf, 0x3057, &W) || !qs(dpy, surf, 0x3056, &H) || W <= 0 || H <= 0) return;
    if (!r->chk) {
        r->chk = true;
        gs_t gs = (gs_t)gl_fn("glGetString");
        const char *v = gs ? (const char *)gs(0x1F02) : nullptr;
        r->es3 = v && strstr(v, "OpenGL ES 3");
    }
    if (!r->es3) return;
    int nw = W * g_rspct / 100, nh = H * g_rspct / 100;
    if (nw < 2) nw = 2;
    if (nh < 2) nh = 2;
    // 1) show last frame: scaled offscreen -> window
    if (r->bound && r->fbo && r->W == W && r->H == H) {
        isen_t isen = (isen_t)gl_fn("glIsEnabled");
        en_t en = (en_t)gl_fn("glEnable"), dis = (en_t)gl_fn("glDisable");
        blit_t bl = (blit_t)real_in("libGLESv2.so", &r_gblit, "glBlitFramebuffer", (void *)hook_gblit);
        bool sc = isen && isen(0x0C11);
        if (sc && dis) dis(0x0C11);
        rbind(0x8CA8, r->fbo);
        rbind(0x8CA9, 0);
        if (bl) bl(0, 0, r->w, r->h, 0, 0, W, H, 0x4000, 0x2601);
        if (sc && en) en(0x0C11);
    }
    // 2) create or resize the offscreen target
    if (!r->fbo || r->W != W || r->H != H) {
        gen_t gf = (gen_t)gl_fn("glGenFramebuffers"), gr = (gen_t)gl_fn("glGenRenderbuffers");
        bind_t br = (bind_t)gl_fn("glBindRenderbuffer");
        rbs_t st = (rbs_t)gl_fn("glRenderbufferStorage");
        geti_t gi = (geti_t)real_in("libGLESv2.so", &r_ggi, "glGetIntegerv", (void *)hook_ggi);
        fr_t fr = (fr_t)real_in("libGLESv2.so", &r_gfr, "glFramebufferRenderbuffer", (void *)hook_gfr);
        if (!gf || !gr || !br || !st || !gi || !fr) return;
        bool fresh = !r->fbo;
        if (fresh) { gf(1, &r->fbo); gr(1, &r->rbc); gr(1, &r->rbd); }
        int old = 0;
        gi(0x8CA7, &old);
        br(0x8D41, r->rbc); st(0x8D41, 0x8058, nw, nh);
        br(0x8D41, r->rbd); st(0x8D41, 0x88F0, nw, nh);
        br(0x8D41, (unsigned)old);
        if (fresh) {
            rbind(0x8D40, r->fbo);
            fr(0x8D40, 0x8CE0, 0x8D41, r->rbc);
            fr(0x8D40, 0x821A, 0x8D41, r->rbd);
        }
        r->W = W; r->H = H; r->w = nw; r->h = nh;
    }
    // 3) put the app's bindings back, redirected to the offscreen target while it thinks the default framebuffer is bound
    r->bound = true;
    rbind(0x8CA9, t_fbo == 0 ? r->fbo : t_fbo);
    rbind(0x8CA8, t_rfbo == 0 ? r->fbo : t_rfbo);
    vp_set(red());
}

static unsigned hook_esb(void *d, void *s) {
    typedef unsigned (*f_t)(void *, void *);
    f_t real = (f_t)real_in("libEGL.so", &r_esb, "eglSwapBuffers", (void *)hook_esb);
    if (!real) return 0;
    if (g_rs) rs_pre(d, s);
    return real(d, s);
}
#define ESBD(NAME, R)                                                                   \
    static unsigned hook_##NAME(void *d, void *s, int *rc, int n) {                     \
        typedef unsigned (*f_t)(void *, void *, int *, int);                            \
        f_t real = (f_t)real_in("libEGL.so", &R, #NAME, (void *)hook_##NAME);           \
        if (!real) return 0;                                                            \
        if (g_rs) rs_pre(d, s);                                                         \
        return real(d, s, rc, n);                                                       \
    }
ESBD(eglSwapBuffersWithDamageKHR, r_esbk)
ESBD(eglSwapBuffersWithDamageEXT, r_esbe)

static unsigned hook_emc(void *d, void *dr, void *rd, void *ctx) {
    typedef unsigned (*f_t)(void *, void *, void *, void *);
    f_t real = (f_t)real_in("libEGL.so", &r_emc, "eglMakeCurrent", (void *)hook_emc);
    if (!real) return 0;
    unsigned ok = real(d, dr, rd, ctx);
    if (ok) {
        t_ctx = ctx; t_rs = nullptr; t_fbo = t_rfbo = 0; t_sk = false;
        if (g_rs && ctx) {
            pthread_mutex_lock(&g_rsmu);
            auto it = g_rsmap.find(ctx);
            if (it != g_rsmap.end()) t_rs = &it->second;
            pthread_mutex_unlock(&g_rsmu);
        }
    }
    return ok;
}
static unsigned hook_edc(void *d, void *ctx) {
    typedef unsigned (*f_t)(void *, void *);
    f_t real = (f_t)real_in("libEGL.so", &r_edc, "eglDestroyContext", (void *)hook_edc);
    if (!real) return 0;
    pthread_mutex_lock(&g_rsmu);
    g_rsmap.erase(ctx);
    if (t_ctx == ctx) t_rs = nullptr;
    pthread_mutex_unlock(&g_rsmu);
    return real(d, ctx);
}

// ---------- OpenCL fast math ----------
static void *r_cbp;
static int hook_cbp(void *prog, unsigned nd, void *const *dev, const char *opt, void (*cb)(void *, void *), void *ud) {
    typedef int (*cbp_t)(void *, unsigned, void *const *, const char *, void (*)(void *, void *), void *);
    cbp_t real = (cbp_t)(r_cbp ? r_cbp : (r_cbp = sym_in("libOpenCL.so", "clBuildProgram")));
    if (!real || real == (cbp_t)hook_cbp) return -30;
    if (g_cl && !(opt && strstr(opt, "-cl-fast-relaxed-math"))) {
        std::string o = opt ? opt : "";
        o += " -cl-fast-relaxed-math -cl-mad-enable";
        int r = real(prog, nd, dev, o.c_str(), cb, ud);
        if (r != -43) return r;  // CL_INVALID_BUILD_OPTIONS: retry untouched
    }
    return real(prog, nd, dev, opt, cb, ud);
}

struct Tgt { const char *n; void *fn; void **real; bool *on; };
#define AFT(n) {#n, (void *)hook_##n, &r_##n, &g_tex}

static void *r_egpa;
static void *hook_egpa(const char *name);
static Tgt g_tgt[] = {
    AFT(glTexParameterf), AFT(glTexParameterfv), AFT(glTexParameteri), AFT(glTexParameteriv),
    AFT(glSamplerParameterf), AFT(glSamplerParameterfv), AFT(glSamplerParameteri), AFT(glSamplerParameteriv),
    {"glShaderSource", (void *)hook_gss, &r_gss, &g_gss},
    {"glTexImage2D", (void *)hook_gti2d, &r_gti2d, &g_dson},
    {"glTexSubImage2D", (void *)hook_gtsi2d, &r_gtsi2d, &g_dson},
    {"glBindTexture", (void *)hook_gbt, &r_gbt, &g_trk},
    {"glActiveTexture", (void *)hook_gat, &r_gat, &g_trk},
    {"glBindBuffer", (void *)hook_gbb, &r_gbb, &g_dson},
    {"glDeleteTextures", (void *)hook_gdt, &r_gdt, &g_trk},
    {"glPixelStorei", (void *)hook_gps, &r_gps, &g_dson},
    {"glTexStorage2D", (void *)hook_gts2d, &r_gts2d, &g_mskip},
    {"glCompressedTexImage2D", (void *)hook_gcti2d, &r_gcti2d, &g_mskip},
    {"glCompressedTexSubImage2D", (void *)hook_gctsi2d, &r_gctsi2d, &g_mskip},
    {"glBindFramebuffer", (void *)hook_gbf, &r_gbf, &g_fbt},
    {"glViewport", (void *)hook_gvp, &r_gvp, &g_fbt},
    {"glScissor", (void *)hook_gsc, &r_gsc, &g_fbt},
    {"glFramebufferTexture2D", (void *)hook_gft2d, &r_gft2d, &g_fbt},
    {"glFramebufferTextureLayer", (void *)hook_gftl, &r_gftl, &g_fbt},
    {"glFramebufferRenderbuffer", (void *)hook_gfr, &r_gfr, &g_fbt},
    {"glDeleteFramebuffers", (void *)hook_gdf, &r_gdf, &g_fbt},
    {"glDrawArrays", (void *)hook_glDrawArrays, &r_glDrawArrays, &g_ss},
    {"glDrawElements", (void *)hook_glDrawElements, &r_glDrawElements, &g_ss},
    {"glDrawArraysInstanced", (void *)hook_glDrawArraysInstanced, &r_glDrawArraysInstanced, &g_ss},
    {"glDrawElementsInstanced", (void *)hook_glDrawElementsInstanced, &r_glDrawElementsInstanced, &g_ss},
    {"glDrawRangeElements", (void *)hook_glDrawRangeElements, &r_glDrawRangeElements, &g_ss},
    {"glBlitFramebuffer", (void *)hook_gblit, &r_gblit, &g_rs},
    {"glInvalidateFramebuffer", (void *)hook_glInvalidateFramebuffer, &r_ginv, &g_rs},
    {"glDiscardFramebufferEXT", (void *)hook_glDiscardFramebufferEXT, &r_gdisc, &g_rs},
    {"glGetIntegerv", (void *)hook_ggi, &r_ggi, &g_rs},
    {"eglSwapBuffers", (void *)hook_esb, &r_esb, &g_rs},
    {"eglSwapBuffersWithDamageKHR", (void *)hook_eglSwapBuffersWithDamageKHR, &r_esbk, &g_rs},
    {"eglSwapBuffersWithDamageEXT", (void *)hook_eglSwapBuffersWithDamageEXT, &r_esbe, &g_rs},
    {"eglMakeCurrent", (void *)hook_emc, &r_emc, &g_fbt},
    {"eglDestroyContext", (void *)hook_edc, &r_edc, &g_rs},
    {"clBuildProgram", (void *)hook_cbp, &r_cbp, &g_cl},
    {"eglGetProcAddress", (void *)hook_egpa, &r_egpa, &g_egl},
};

// Engines that fetch GL entry points through EGL get our hooks too.
static void *hook_egpa(const char *name) {
    typedef void *(*egpa_t)(const char *);
    egpa_t real = (egpa_t)(r_egpa ? r_egpa : (r_egpa = sym_in("libEGL.so", "eglGetProcAddress")));
    if (!real || real == (egpa_t)hook_egpa) return nullptr;
    void *p = real(name);
    if (p && name)
        for (auto &t : g_tgt)
            if (*t.on && !strcmp(name, t.n)) { if (!*t.real) *t.real = p; return t.fn; }
    return p;
}

// ---------- GOT patcher ----------
#if defined(__LP64__)
typedef ElfW(Rela) Rel;
#define RSYM(i) ((i) >> 32)
#define RTYPE(i) ((i) & 0xffffffffu)
enum { T_SLOT = 1026, T_GLOB = 1025, T_ABS = 257 };
#else
typedef ElfW(Rel) Rel;
#define RSYM(i) ((i) >> 8)
#define RTYPE(i) ((i) & 0xffu)
enum { T_SLOT = 22, T_GLOB = 21, T_ABS = 2 };
#endif

struct Map { uintptr_t s, e; int prot; };
static void read_maps(std::vector<Map> &v) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return;
    char line[1024];
    while (fgets(line, sizeof line, f)) {
        unsigned long s, e;
        char p[8];
        if (sscanf(line, "%lx-%lx %7s", &s, &e, p) == 3)
            v.push_back({s, e, (p[0] == 'r' ? PROT_READ : 0) | (p[1] == 'w' ? PROT_WRITE : 0) | (p[2] == 'x' ? PROT_EXEC : 0)});
    }
    fclose(f);
}

static void put(std::vector<Map> &m, void **slot, void *fn) {
    if (*slot == fn) return;
    if (m.empty()) read_maps(m);
    static const uintptr_t ps = (uintptr_t)sysconf(_SC_PAGESIZE);
    uintptr_t pg = (uintptr_t)slot & ~(ps - 1);
    int pr = 0;
    for (auto &x : m) if (pg >= x.s && pg < x.e) { pr = x.prot; break; }
    if (!(pr & PROT_READ)) return;
    bool w = pr & PROT_WRITE;
    if (!w && mprotect((void *)pg, ps, pr | PROT_WRITE)) return;
    __atomic_store_n(slot, fn, __ATOMIC_RELAXED);
    if (!w) mprotect((void *)pg, ps, pr);
}

static void scan(uintptr_t bias, const char *str, const ElfW(Sym) *sym, uintptr_t tab, size_t sz, std::vector<Map> &maps) {
    if (!tab || !sz || !str || !sym) return;
    for (size_t o = 0; o + sizeof(Rel) <= sz; o += sizeof(Rel)) {
        const Rel *r = (const Rel *)(tab + o);
        unsigned type = RTYPE(r->r_info);
        if (type != T_SLOT && type != T_GLOB && type != T_ABS) continue;
#if defined(__LP64__)
        if (type == T_ABS && r->r_addend) continue;
#else
        if (type == T_ABS) continue;
#endif
        size_t si = RSYM(r->r_info);
        if (!si || sym[si].st_shndx != SHN_UNDEF) continue;
        const char *nm = str + sym[si].st_name;
        for (auto &t : g_tgt)
            if (*t.on && !strcmp(nm, t.n)) put(maps, (void **)(bias + r->r_offset), t.fn);
    }
}

static int g_marker;
static bool in_self(const dl_phdr_info *i) {
    uintptr_t a = (uintptr_t)&g_marker;
    for (int k = 0; k < i->dlpi_phnum; k++) {
        const ElfW(Phdr) &p = i->dlpi_phdr[k];
        if (p.p_type == PT_LOAD && a >= i->dlpi_addr + p.p_vaddr && a < i->dlpi_addr + p.p_vaddr + p.p_memsz) return true;
    }
    return false;
}
static bool skip_name(const char *n) {
    static const char *k[] = {"/libc.so", "/libdl.so", "linker", "libEGL", "libGLES", "libOpenCL"};
    for (auto s : k) if (strstr(n, s)) return true;
    return false;
}

static int each_lib(dl_phdr_info *i, size_t, void *d) {
    auto &maps = *(std::vector<Map> *)d;
    const char *n = i->dlpi_name;
    if (!n || !*n || skip_name(n) || in_self(i)) return 0;
    const ElfW(Dyn) *dyn = nullptr;
    for (int k = 0; k < i->dlpi_phnum; k++)
        if (i->dlpi_phdr[k].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn) *)(i->dlpi_addr + i->dlpi_phdr[k].p_vaddr); break; }
    if (!dyn) return 0;
    uintptr_t bias = i->dlpi_addr, str = 0, sym = 0, jmp = 0, rel = 0;
    size_t jsz = 0, rsz = 0;
    auto fix = [&](uintptr_t p) { return p < bias ? p + bias : p; };
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_STRTAB: str = fix(dyn->d_un.d_ptr); break;
            case DT_SYMTAB: sym = fix(dyn->d_un.d_ptr); break;
            case DT_JMPREL: jmp = fix(dyn->d_un.d_ptr); break;
            case DT_PLTRELSZ: jsz = dyn->d_un.d_val; break;
#if defined(__LP64__)
            case DT_RELA: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELASZ: rsz = dyn->d_un.d_val; break;
#else
            case DT_REL: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELSZ: rsz = dyn->d_un.d_val; break;
#endif
        }
    }
    // shortcut: packed (APS2/RELR) relocs aren't parsed; PLT slots (DT_JMPREL) cover normal GL calls. upgrade: add sleb128 decoder.
    scan(bias, (const char *)str, (const ElfW(Sym) *)sym, jmp, jsz, maps);
    scan(bias, (const char *)str, (const ElfW(Sym) *)sym, rel, rsz, maps);
    return 0;
}

// Export-table patch: libGLESv2.so / libEGL.so keep their symbol st_value relative to the load bias, so pointing it at
// our hook makes the linker bind every later (or still lazy) importer to the hook. The original address is saved first.
#ifndef DT_GNU_HASH
#define DT_GNU_HASH 0x6ffffef5
#endif
// Exact dynsym entry count from DT_HASH (nchain) or DT_GNU_HASH (walk the last bucket's chain).
static size_t sym_count(uintptr_t hash, uintptr_t gnu) {
    if (hash) return ((const uint32_t *)hash)[1];
    if (!gnu) return 0;
    const uint32_t *h = (const uint32_t *)gnu;
    uint32_t nb = h[0], off = h[1], bloom = h[2];
    const uint32_t *bk = (const uint32_t *)((const ElfW(Addr) *)(h + 4) + bloom);
    const uint32_t *ch = bk + nb;
    uint32_t last = 0;
    for (uint32_t k = 0; k < nb; k++) if (bk[k] > last) last = bk[k];
    if (last < off) return off;
    while (!(ch[last - off] & 1)) last++;
    return (size_t)last + 1;
}

static int exp_cb(dl_phdr_info *i, size_t, void *d) {
    auto &maps = *(std::vector<Map> *)d;
    const char *n = i->dlpi_name;
    if (!n) return 0;
    const char *b = strrchr(n, '/');
    b = b ? b + 1 : n;
    if (strcmp(b, "libGLESv2.so") && strcmp(b, "libEGL.so") && strcmp(b, "libOpenCL.so")) return 0;
    const ElfW(Dyn) *dyn = nullptr;
    for (int k = 0; k < i->dlpi_phnum; k++)
        if (i->dlpi_phdr[k].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn) *)(i->dlpi_addr + i->dlpi_phdr[k].p_vaddr); break; }
    if (!dyn) return 0;
    uintptr_t bias = i->dlpi_addr, str = 0, sym = 0, hash = 0, gnu = 0;
    size_t strsz = 0;
    auto fix = [&](uintptr_t p) { return p < bias ? p + bias : p; };
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_STRTAB: str = fix(dyn->d_un.d_ptr); break;
            case DT_SYMTAB: sym = fix(dyn->d_un.d_ptr); break;
            case DT_STRSZ: strsz = dyn->d_un.d_val; break;
            case DT_HASH: hash = fix(dyn->d_un.d_ptr); break;
            case DT_GNU_HASH: gnu = fix(dyn->d_un.d_ptr); break;
        }
    }
    size_t cnt = sym_count(hash, gnu);
    if (!str || !sym || !strsz || !cnt) return 0;
    for (size_t k = 1; k < cnt; k++) {
        ElfW(Sym) *s = (ElfW(Sym) *)sym + k;
        if (s->st_shndx == SHN_UNDEF || !s->st_name || s->st_name >= strsz) continue;
        const char *nm = (const char *)str + s->st_name;
        for (auto &t : g_tgt) {
            if (!*t.on || strcmp(nm, t.n)) continue;
            if (!*t.real) *t.real = (void *)(bias + s->st_value);
            put(maps, (void **)&s->st_value, (void *)((uintptr_t)t.fn - bias));
        }
    }
    return 0;
}

// Runs once per hooked process, right after specialization (no thread, no timer).
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
static void patch_all() {
    pthread_mutex_lock(&g_mu);
    std::vector<Map> maps;
    dl_iterate_phdr(exp_cb, &maps);   // 1) libraries loaded from now on bind to the hooks
    maps.clear();
    dl_iterate_phdr(each_lib, &maps); // 2) libraries already bound get their GOT slots patched
    pthread_mutex_unlock(&g_mu);
}

// libOpenCL usually loads after startup, so (opencl=1 only) re-run the patch right after every System.loadLibrary.
// Event-driven, no thread. shortcut: apps that dlopen libOpenCL from native code only are missed; upgrade: none without a dlopen hook.
static jstring (*g_old_load)(JNIEnv *, jclass, jstring, jobject, jobject);
static jstring my_load(JNIEnv *e, jclass c, jstring f, jobject l, jobject x) {
    jstring r = g_old_load(e, c, f, l, x);
    patch_all();
    return r;
}

// ---------- config + module ----------
// One config key. Used for the top (defaults) section and for profile overrides.
static void apply_kv(const char *l, const char *v) {
    if (!strcmp(l, "af_off")) g_af = atoi(v) != 0;
    else if (!strcmp(l, "mip_bilinear")) g_bil = atoi(v) != 0;
    else if (!strcmp(l, "tex_nearest")) g_near = atoi(v) != 0;
    else if (!strcmp(l, "tex_min_lod")) { g_lod = atoi(v); if (g_lod < 0) g_lod = 0; if (g_lod > 4) g_lod = 4; }
    else if (!strcmp(l, "fp16")) g_fp16 = atoi(v) != 0;
    else if (!strcmp(l, "pbr_fastmath")) g_pbr = atoi(v) != 0;
    else if (!strcmp(l, "ibl_min_lod")) { g_ibl = atoi(v); if (g_ibl < 0) g_ibl = 0; if (g_ibl > 4) g_ibl = 4; }
    else if (!strcmp(l, "tex_downscale")) { int d = atoi(v); g_dsh = d == 2 ? 1 : d == 4 ? 2 : 0; }
    else if (!strcmp(l, "tex_downscale_min")) { g_dsmin = atoi(v); if (g_dsmin < 64) g_dsmin = 64; }
    else if (!strcmp(l, "pbr_no_normalmap")) g_nonorm = atoi(v) != 0;
    else if (!strcmp(l, "pbr_normal_names")) g_nnames = v;
    else if (!strcmp(l, "pbr_ibl_blur")) { g_iblb = atoi(v); if (g_iblb < 0) g_iblb = 0; if (g_iblb > 8) g_iblb = 8; }
    else if (!strcmp(l, "pbr_ibl_names")) g_inames = v;
    else if (!strcmp(l, "tex_mip_skip")) { g_mssh = atoi(v); if (g_mssh < 0) g_mssh = 0; if (g_mssh > 2) g_mssh = 2; }
    else if (!strcmp(l, "tex_mip_skip_min")) { g_msmin = atoi(v); if (g_msmin < 64) g_msmin = 64; }
    else if (!strcmp(l, "shadow_skip")) g_ss = atoi(v) != 0;
    else if (!strcmp(l, "render_scale")) { g_rspct = atoi(v); if (g_rspct < 25 || g_rspct > 99) g_rspct = 100; }
    else if (!strcmp(l, "opencl")) g_cl = atoi(v) != 0;
    else if (!strcmp(l, "exclude")) {
        std::string t(v);
        char *sp;
        for (char *x = strtok_r(&t[0], " ,", &sp); x; x = strtok_r(nullptr, " ,", &sp)) g_excl.push_back(x);
    }
}

static char *trim(char *s) {
    while (*s == ' ' || *s == '\t') s++;
    char *e = s + strlen(s);
    while (e > s && (e[-1] == ' ' || e[-1] == '\t')) *--e = 0;
    return s;
}

// config.txt: top keys are the defaults. [name] sections are profiles (only the keys to change); [apps] maps
// "package = profile profile". Profiles are merged on top of the defaults, the FIRST listed profile wins on a clash.
// shortcut: matches the package name only (process suffix after ':' ignored), no wildcards.
static void load_cfg(int dfd, const std::string &pkg) {
    g_af = g_fp16 = g_cl = true;
    g_bil = true;
    g_near = false;
    g_lod = 0;
    g_pbr = false;
    g_mssh = 0;
    g_msmin = 512;
    g_ss = false;
    g_rspct = 100;
    g_nonorm = false;
    g_iblb = 0;
    g_nnames = "normal,nrm,bump";
    g_inames = "env,refl,ibl,irrad,radiance,prefilter,specular";
    g_ibl = 0;
    g_dsh = 0;
    g_dsmin = 1024;
    g_excl.clear();
    int fd = dfd >= 0 ? openat(dfd, "config.txt", O_RDONLY) : -1;
    if (fd < 0) return;
    char buf[16384];
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    if (n <= 0) return;
    buf[n] = 0;
    typedef std::vector<std::pair<std::string, std::string>> KV;
    std::vector<std::pair<std::string, KV>> profs;
    std::vector<std::string> want;
    int sec = -1;  // -1 defaults, -2 [apps], >=0 profile index
    for (char *l = strtok(buf, "\r\n"); l; l = strtok(nullptr, "\r\n")) {
        l = trim(l);
        if (*l == '#' || !*l) continue;
        if (*l == '[') {
            char *e = strchr(l, ']');
            if (!e) continue;
            *e = 0;
            std::string nm(trim(l + 1));
            if (nm == "apps") sec = -2;
            else { profs.push_back({nm, KV()}); sec = (int)profs.size() - 1; }
            continue;
        }
        char *v = strchr(l, '=');
        if (!v) continue;
        *v++ = 0;
        char *k = trim(l);
        v = trim(v);
        if (sec == -1) apply_kv(k, v);
        else if (sec >= 0) profs[sec].second.push_back({k, v});
        else if (pkg == k) {
            char *sp;
            for (char *t = strtok_r(v, " ,", &sp); t; t = strtok_r(nullptr, " ,", &sp)) want.push_back(t);
        }
    }
    std::vector<std::string> done;
    for (auto &w : want)
        for (auto &pr : profs) {
            if (pr.first != w) continue;
            for (auto &kv : pr.second) {
                if (std::find(done.begin(), done.end(), kv.first) != done.end()) continue;
                apply_kv(kv.first.c_str(), kv.second.c_str());
            }
            for (auto &kv : pr.second) done.push_back(kv.first);
        }
}

class GpuMath : public zygisk::ModuleBase {
    zygisk::Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
    bool on_ = false;

public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override { api_ = api; env_ = env; }

    void preAppSpecialize(zygisk::AppSpecializeArgs *a) override {
        if (!a->nice_name || !a->app_data_dir) return;  // isolated processes
        const char *nm = env_->GetStringUTFChars(a->nice_name, nullptr);
        if (!nm) return;
        std::string name(nm);
        env_->ReleaseStringUTFChars(a->nice_name, nm);
        // bootanimation is a native binary (never forked from zygote); guard anyway.
        if (name.find("zygote") != std::string::npos || name.find("bootanim") != std::string::npos) return;
        std::string pkg = name.substr(0, name.find(':'));
        load_cfg(api_->getModuleDir(), pkg);
        g_tex = g_af || g_bil || g_near || g_lod > 0 || g_ibl > 0;
        g_gss = g_fp16 || g_pbr || g_nonorm || g_iblb > 0;
        g_dson = g_dsh > 0;
        g_mskip = g_mssh > 0;
        g_rs = g_rspct < 100;
        g_fbt = g_rs || g_ss;
        g_trk = g_dson || g_mskip;
        if (!g_tex && !g_gss && !g_cl && !g_dson && !g_mskip && !g_fbt) return;
        for (auto &x : g_excl) if (x == pkg) return;
        on_ = true;
        if (g_cl) {
            JNINativeMethod m[1] = {{"nativeLoad", "(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/Class;)Ljava/lang/String;", (void *)my_load}};
            api_->hookJniNativeMethods(env_, "java/lang/Runtime", m, 1);
            if (!m[0].fnPtr) {
                m[0] = {"nativeLoad", "(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/lang/String;", (void *)my_load};
                api_->hookJniNativeMethods(env_, "java/lang/Runtime", m, 1);
            }
            g_old_load = (decltype(g_old_load))m[0].fnPtr;
        }
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!on_) { api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY); return; }
        patch_all();
    }

    void preServerSpecialize(zygisk::ServerSpecializeArgs *) override {
        api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }
};

REGISTER_ZYGISK_MODULE(GpuMath)
