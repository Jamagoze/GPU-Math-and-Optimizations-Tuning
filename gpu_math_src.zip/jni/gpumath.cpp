// gpu_math: global Zygisk module. GLES texture load reduction (anisotropic off, bilinear mips, nearest, min LOD)
// and fragment shader default precision highp->mediump (fp16 math).
// Event-driven, no polling: libGLESv2/libEGL's export table is rewritten so every library loaded later
// (or still lazily bound) resolves glTex/SamplerParameter* to our hooks; libraries already bound get a one-time GOT patch.
#include <jni.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string>
#include <vector>
#include "zygisk.hpp"

static bool g_af = true, g_fp16 = true, g_egl = true;
static std::vector<std::string> g_excl;


static void *sym_in(const char *lib, const char *name) {
    void *h = dlopen(lib, RTLD_NOW | RTLD_NOLOAD);
    if (!h) h = dlopen(lib, RTLD_NOW);
    void *p = h ? dlsym(h, name) : nullptr;
    if (!p) p = dlsym(RTLD_DEFAULT, name);
    return p;
}

// ---------- texture load reduction ----------
// af_off:        GL_TEXTURE_MAX_ANISOTROPY_EXT (0x84FE) forced to 1.
// mip_bilinear:  MIN_FILTER LINEAR_MIPMAP_LINEAR -> LINEAR_MIPMAP_NEAREST (NEAREST_MIPMAP_LINEAR -> NEAREST_MIPMAP_NEAREST).
// tex_nearest:   MAG/MIN filters LINEAR -> NEAREST, all mipmapped MIN filters -> NEAREST_MIPMAP_NEAREST.
// tex_min_lod:   GL_TEXTURE_MIN_LOD (0x813A) raised to N on textures and samplers (ES 3.x contexts only).
static bool g_bil = false, g_near = false, g_tex = true;
static int g_lod = 0;
static const float kf = 1.0f;
static const int ki = 1;

static int adj_i(unsigned p, int v) {
    if (g_af && p == 0x84FE) return 1;
    if (g_near) {
        if (p == 0x2800 && v == 0x2601) return 0x2600;
        if (p == 0x2801) {
            if (v == 0x2601) return 0x2600;
            if (v >= 0x2701 && v <= 0x2703) return 0x2700;
        }
    } else if (g_bil && p == 0x2801) {
        if (v == 0x2703) return 0x2701;
        if (v == 0x2702) return 0x2700;
    }
    if (p == 0x813A && g_lod > 0 && v < g_lod) return g_lod;
    return v;
}
static float adj_f(unsigned p, float v) {
    if (p == 0x84FE) return g_af ? 1.0f : v;
    if (p == 0x813A) return (g_lod > 0 && v < g_lod) ? (float)g_lod : v;
    int i = (int)v, j = adj_i(p, i);
    return j == i ? v : (float)j;
}
static bool relevant(unsigned p) { return p == 0x84FE || p == 0x2800 || p == 0x2801 || p == 0x813A; }

static bool es3() {
    static __thread int c;  // 0 unknown, 1 ES3+, 2 ES2
    if (c) return c == 1;
    typedef const unsigned char *(*gs_t)(unsigned);
    gs_t gs = (gs_t)sym_in("libGLESv2.so", "glGetString");
    const char *v = gs ? (const char *)gs(0x1F02) : nullptr;  // GL_VERSION
    if (!v) return false;                                       // no context current: don't cache
    c = strstr(v, "OpenGL ES 3") ? 1 : 2;
    return c == 1;
}
// Sets MIN_LOD right after a MIN_FILTER call, using the real (unhooked) glTex/SamplerParameterf.
static void inj(void **rp, const char *name, void *self, unsigned a) {
    if (!*rp) *rp = sym_in("libGLESv2.so", name);
    if (*rp && *rp != self && es3()) ((void (*)(unsigned, unsigned, float))*rp)(a, 0x813A, (float)g_lod);
}

#define TEXHOOK(fn, T, ADJ, TMP, INJR, INJN)                                              \
    static void *r_##fn;                                                            \
    static void hook_##fn(unsigned a, unsigned p, T v) {                            \
        void *r = r_##fn ? r_##fn : (r_##fn = sym_in("libGLESv2.so", #fn));         \
        if (!r || r == (void *)hook_##fn) return;                                   \
        TMP                                                                         \
        if (relevant(p)) { ADJ }                                                    \
        ((void (*)(unsigned, unsigned, T))r)(a, p, v);                              \
        if (g_lod > 0 && p == 0x2801) inj(&INJR, INJN, (void *)hook_##fn, a);              \
    }
TEXHOOK(glTexParameterf, float, v = adj_f(p, v);, , r_glTexParameterf, "glTexParameterf")
TEXHOOK(glTexParameterfv, const float *, if (v) { t = adj_f(p, *v); v = &t; }, float t;, r_glTexParameterf, "glTexParameterf")
TEXHOOK(glTexParameteri, int, v = adj_i(p, v);, , r_glTexParameterf, "glTexParameterf")
TEXHOOK(glTexParameteriv, const int *, if (v) { t = adj_i(p, *v); v = &t; }, int t;, r_glTexParameterf, "glTexParameterf")
TEXHOOK(glSamplerParameterf, float, v = adj_f(p, v);, , r_glSamplerParameterf, "glSamplerParameterf")
TEXHOOK(glSamplerParameterfv, const float *, if (v) { t = adj_f(p, *v); v = &t; }, float t;, r_glSamplerParameterf, "glSamplerParameterf")
TEXHOOK(glSamplerParameteri, int, v = adj_i(p, v);, , r_glSamplerParameterf, "glSamplerParameterf")
TEXHOOK(glSamplerParameteriv, const int *, if (v) { t = adj_i(p, *v); v = &t; }, int t;, r_glSamplerParameterf, "glSamplerParameterf")

// ---------- fp16 shader rewrite ----------
static bool isid(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_'; }
static bool isws(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r'; }
static bool word_at(const std::string &s, size_t i, const char *w) {
    size_t l = strlen(w);
    if (i + l > s.size() || s.compare(i, l, w) != 0) return false;
    if (i > 0 && isid(s[i - 1])) return false;
    if (i + l < s.size() && isid(s[i + l])) return false;
    return true;
}
static size_t skipws(const std::string &s, size_t i) { while (i < s.size() && isws(s[i])) i++; return i; }
static bool starts(const std::string &t, const char *p) { return t.compare(0, strlen(p), p) == 0; }
static bool is_float_type(const std::string &t) {
    return t == "float" || t == "vec2" || t == "vec3" || t == "vec4" || starts(t, "mat");
}
static bool is_safe_type(const std::string &t) {
    return t == "highp" || t == "mediump" || t == "lowp" || t == "int" || t == "uint" || t == "bool" ||
           starts(t, "ivec") || starts(t, "uvec") || starts(t, "bvec") || starts(t, "sampler") ||
           starts(t, "isampler") || starts(t, "usampler") || starts(t, "image") || starts(t, "iimage") ||
           starts(t, "uimage");
}
struct Edit { size_t pos, del; const char *ins; };

// Fragment shaders only (no gl_Position). Uniforms are pinned to highp so they still match the vertex shader.
// Shaders with uniform blocks/structs are left untouched (precision must match across stages).
static bool fp16_rewrite(const std::string &s, std::string &out) {
    if (s.find("gl_Position") != std::string::npos || s.find("local_size") != std::string::npos) return false;
    std::vector<Edit> ed;
    bool def = false;
    size_t n = s.size();
    for (size_t i = 0; i < n; i++) {
        char c = s[i];
        if (c == 'p' && word_at(s, i, "precision")) {
            size_t j = skipws(s, i + 9);
            if (j < n && word_at(s, j, "highp")) {
                size_t k = skipws(s, j + 5);
                if (k < n && word_at(s, k, "float")) { ed.push_back({j, 5, "mediump"}); def = true; }
            }
            i += 8;
        } else if (c == 'u' && word_at(s, i, "uniform")) {
            size_t j = skipws(s, i + 7), e = j;
            while (e < n && isid(s[e])) e++;
            std::string t = s.substr(j, e - j);
            if (is_float_type(t)) ed.push_back({j, 0, "highp "});
            else if (!is_safe_type(t)) return false;
            i += 6;
        }
    }
    if (!def) return false;
    out.reserve(n + ed.size() * 8);
    size_t p = 0;
    for (auto &e : ed) { out.append(s, p, e.pos - p); out += e.ins; p = e.pos + e.del; }
    out.append(s, p, std::string::npos);
    return true;
}

static void *r_gss;
static void hook_gss(unsigned sh, int n, const char *const *str, const int *len) {
    typedef void (*gss_t)(unsigned, int, const char *const *, const int *);
    gss_t real = (gss_t)(r_gss ? r_gss : (r_gss = sym_in("libGLESv2.so", "glShaderSource")));
    if (!real || real == (gss_t)hook_gss) return;
    if (g_fp16 && n > 0 && str) {
        std::string src, out;
        for (int i = 0; i < n; i++) {
            if (!str[i]) continue;
            if (len && len[i] >= 0) src.append(str[i], len[i]); else src.append(str[i]);
        }
        if (fp16_rewrite(src, out)) {
            const char *p = out.c_str();
            int l = (int)out.size();
            real(sh, 1, &p, &l);
            return;
        }
    }
    real(sh, n, str, len);
}

struct Tgt { const char *n; void *fn; void **real; bool *on; };
#define AFT(n) {#n, (void *)hook_##n, &r_##n, &g_tex}

static void *r_egpa;
static void *hook_egpa(const char *name);
static Tgt g_tgt[] = {
    AFT(glTexParameterf), AFT(glTexParameterfv), AFT(glTexParameteri), AFT(glTexParameteriv),
    AFT(glSamplerParameterf), AFT(glSamplerParameterfv), AFT(glSamplerParameteri), AFT(glSamplerParameteriv),
    {"glShaderSource", (void *)hook_gss, &r_gss, &g_fp16},
    {"eglGetProcAddress", (void *)hook_egpa, &r_egpa, &g_egl},
};

// Engines that fetch GL entry points through EGL get our hooks too.
static void *hook_egpa(const char *name) {
    typedef void *(*egpa_t)(const char *);
    egpa_t real = (egpa_t)(r_egpa ? r_egpa : (r_egpa = sym_in("libEGL.so", "eglGetProcAddress")));
    if (!real || real == (egpa_t)hook_egpa) return nullptr;
    void *p = real(name);
    if (p && name)
        for (auto &t : g_tgt)
            if (*t.on && !strcmp(name, t.n)) { if (!*t.real) *t.real = p; return t.fn; }
    return p;
}

// ---------- GOT patcher ----------
#if defined(__LP64__)
typedef ElfW(Rela) Rel;
#define RSYM(i) ((i) >> 32)
#define RTYPE(i) ((i) & 0xffffffffu)
enum { T_SLOT = 1026, T_GLOB = 1025, T_ABS = 257 };
#else
typedef ElfW(Rel) Rel;
#define RSYM(i) ((i) >> 8)
#define RTYPE(i) ((i) & 0xffu)
enum { T_SLOT = 22, T_GLOB = 21, T_ABS = 2 };
#endif

struct Map { uintptr_t s, e; int prot; };
static void read_maps(std::vector<Map> &v) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return;
    char line[1024];
    while (fgets(line, sizeof line, f)) {
        unsigned long s, e;
        char p[8];
        if (sscanf(line, "%lx-%lx %7s", &s, &e, p) == 3)
            v.push_back({s, e, (p[0] == 'r' ? PROT_READ : 0) | (p[1] == 'w' ? PROT_WRITE : 0) | (p[2] == 'x' ? PROT_EXEC : 0)});
    }
    fclose(f);
}

static void put(std::vector<Map> &m, void **slot, void *fn) {
    if (*slot == fn) return;
    if (m.empty()) read_maps(m);
    static const uintptr_t ps = (uintptr_t)sysconf(_SC_PAGESIZE);
    uintptr_t pg = (uintptr_t)slot & ~(ps - 1);
    int pr = 0;
    for (auto &x : m) if (pg >= x.s && pg < x.e) { pr = x.prot; break; }
    if (!(pr & PROT_READ)) return;
    bool w = pr & PROT_WRITE;
    if (!w && mprotect((void *)pg, ps, pr | PROT_WRITE)) return;
    __atomic_store_n(slot, fn, __ATOMIC_RELAXED);
    if (!w) mprotect((void *)pg, ps, pr);
}

static void scan(uintptr_t bias, const char *str, const ElfW(Sym) *sym, uintptr_t tab, size_t sz, std::vector<Map> &maps) {
    if (!tab || !sz || !str || !sym) return;
    for (size_t o = 0; o + sizeof(Rel) <= sz; o += sizeof(Rel)) {
        const Rel *r = (const Rel *)(tab + o);
        unsigned type = RTYPE(r->r_info);
        if (type != T_SLOT && type != T_GLOB && type != T_ABS) continue;
#if defined(__LP64__)
        if (type == T_ABS && r->r_addend) continue;
#else
        if (type == T_ABS) continue;
#endif
        size_t si = RSYM(r->r_info);
        if (!si || sym[si].st_shndx != SHN_UNDEF) continue;
        const char *nm = str + sym[si].st_name;
        for (auto &t : g_tgt)
            if (*t.on && !strcmp(nm, t.n)) put(maps, (void **)(bias + r->r_offset), t.fn);
    }
}

static int g_marker;
static bool in_self(const dl_phdr_info *i) {
    uintptr_t a = (uintptr_t)&g_marker;
    for (int k = 0; k < i->dlpi_phnum; k++) {
        const ElfW(Phdr) &p = i->dlpi_phdr[k];
        if (p.p_type == PT_LOAD && a >= i->dlpi_addr + p.p_vaddr && a < i->dlpi_addr + p.p_vaddr + p.p_memsz) return true;
    }
    return false;
}
static bool skip_name(const char *n) {
    static const char *k[] = {"/libc.so", "/libdl.so", "linker", "libEGL", "libGLES", "libOpenCL"};
    for (auto s : k) if (strstr(n, s)) return true;
    return false;
}

static int each_lib(dl_phdr_info *i, size_t, void *d) {
    auto &maps = *(std::vector<Map> *)d;
    const char *n = i->dlpi_name;
    if (!n || !*n || skip_name(n) || in_self(i)) return 0;
    const ElfW(Dyn) *dyn = nullptr;
    for (int k = 0; k < i->dlpi_phnum; k++)
        if (i->dlpi_phdr[k].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn) *)(i->dlpi_addr + i->dlpi_phdr[k].p_vaddr); break; }
    if (!dyn) return 0;
    uintptr_t bias = i->dlpi_addr, str = 0, sym = 0, jmp = 0, rel = 0;
    size_t jsz = 0, rsz = 0;
    auto fix = [&](uintptr_t p) { return p < bias ? p + bias : p; };
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_STRTAB: str = fix(dyn->d_un.d_ptr); break;
            case DT_SYMTAB: sym = fix(dyn->d_un.d_ptr); break;
            case DT_JMPREL: jmp = fix(dyn->d_un.d_ptr); break;
            case DT_PLTRELSZ: jsz = dyn->d_un.d_val; break;
#if defined(__LP64__)
            case DT_RELA: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELASZ: rsz = dyn->d_un.d_val; break;
#else
            case DT_REL: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELSZ: rsz = dyn->d_un.d_val; break;
#endif
        }
    }
    // shortcut: packed (APS2/RELR) relocs aren't parsed; PLT slots (DT_JMPREL) cover normal GL calls. upgrade: add sleb128 decoder.
    scan(bias, (const char *)str, (const ElfW(Sym) *)sym, jmp, jsz, maps);
    scan(bias, (const char *)str, (const ElfW(Sym) *)sym, rel, rsz, maps);
    return 0;
}

// Export-table patch: libGLESv2.so / libEGL.so keep their symbol st_value relative to the load bias, so pointing it at
// our hook makes the linker bind every later (or still lazy) importer to the hook. The original address is saved first.
#ifndef DT_GNU_HASH
#define DT_GNU_HASH 0x6ffffef5
#endif
// Exact dynsym entry count from DT_HASH (nchain) or DT_GNU_HASH (walk the last bucket's chain).
static size_t sym_count(uintptr_t hash, uintptr_t gnu) {
    if (hash) return ((const uint32_t *)hash)[1];
    if (!gnu) return 0;
    const uint32_t *h = (const uint32_t *)gnu;
    uint32_t nb = h[0], off = h[1], bloom = h[2];
    const uint32_t *bk = (const uint32_t *)((const ElfW(Addr) *)(h + 4) + bloom);
    const uint32_t *ch = bk + nb;
    uint32_t last = 0;
    for (uint32_t k = 0; k < nb; k++) if (bk[k] > last) last = bk[k];
    if (last < off) return off;
    while (!(ch[last - off] & 1)) last++;
    return (size_t)last + 1;
}

static int exp_cb(dl_phdr_info *i, size_t, void *d) {
    auto &maps = *(std::vector<Map> *)d;
    const char *n = i->dlpi_name;
    if (!n) return 0;
    const char *b = strrchr(n, '/');
    b = b ? b + 1 : n;
    if (strcmp(b, "libGLESv2.so") && strcmp(b, "libEGL.so")) return 0;
    const ElfW(Dyn) *dyn = nullptr;
    for (int k = 0; k < i->dlpi_phnum; k++)
        if (i->dlpi_phdr[k].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn) *)(i->dlpi_addr + i->dlpi_phdr[k].p_vaddr); break; }
    if (!dyn) return 0;
    uintptr_t bias = i->dlpi_addr, str = 0, sym = 0, hash = 0, gnu = 0;
    size_t strsz = 0;
    auto fix = [&](uintptr_t p) { return p < bias ? p + bias : p; };
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_STRTAB: str = fix(dyn->d_un.d_ptr); break;
            case DT_SYMTAB: sym = fix(dyn->d_un.d_ptr); break;
            case DT_STRSZ: strsz = dyn->d_un.d_val; break;
            case DT_HASH: hash = fix(dyn->d_un.d_ptr); break;
            case DT_GNU_HASH: gnu = fix(dyn->d_un.d_ptr); break;
        }
    }
    size_t cnt = sym_count(hash, gnu);
    if (!str || !sym || !strsz || !cnt) return 0;
    for (size_t k = 1; k < cnt; k++) {
        ElfW(Sym) *s = (ElfW(Sym) *)sym + k;
        if (s->st_shndx == SHN_UNDEF || !s->st_name || s->st_name >= strsz) continue;
        const char *nm = (const char *)str + s->st_name;
        for (auto &t : g_tgt) {
            if (!*t.on || strcmp(nm, t.n)) continue;
            if (!*t.real) *t.real = (void *)(bias + s->st_value);
            put(maps, (void **)&s->st_value, (void *)((uintptr_t)t.fn - bias));
        }
    }
    return 0;
}

// Runs once per hooked process, right after specialization (no thread, no timer).
static void patch_all() {
    std::vector<Map> maps;
    dl_iterate_phdr(exp_cb, &maps);   // 1) libraries loaded from now on bind to the hooks
    maps.clear();
    dl_iterate_phdr(each_lib, &maps); // 2) libraries already bound get their GOT slots patched
}

// ---------- config + module ----------
static void load_cfg(int dfd) {
    g_af = g_fp16 = true;
    g_bil = true;
    g_near = false;
    g_lod = 0;
    g_excl.clear();
    int fd = dfd >= 0 ? openat(dfd, "config.txt", O_RDONLY) : -1;
    if (fd < 0) return;
    char buf[4096];
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    if (n <= 0) return;
    buf[n] = 0;
    for (char *l = strtok(buf, "\r\n"); l; l = strtok(nullptr, "\r\n")) {
        while (*l == ' ') l++;
        char *v = strchr(l, '=');
        if (*l == '#' || !v) continue;
        *v++ = 0;
        if (!strcmp(l, "af_off")) g_af = atoi(v) != 0;
        else if (!strcmp(l, "mip_bilinear")) g_bil = atoi(v) != 0;
        else if (!strcmp(l, "tex_nearest")) g_near = atoi(v) != 0;
        else if (!strcmp(l, "tex_min_lod")) { g_lod = atoi(v); if (g_lod < 0) g_lod = 0; if (g_lod > 4) g_lod = 4; }
        else if (!strcmp(l, "fp16")) g_fp16 = atoi(v) != 0;
        else if (!strcmp(l, "exclude")) {
            char *sp;
            for (char *t = strtok_r(v, " ,", &sp); t; t = strtok_r(nullptr, " ,", &sp)) g_excl.push_back(t);
        }
    }
}

class GpuMath : public zygisk::ModuleBase {
    zygisk::Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
    bool on_ = false;

public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override { api_ = api; env_ = env; }

    void preAppSpecialize(zygisk::AppSpecializeArgs *a) override {
        if (!a->nice_name || !a->app_data_dir) return;  // isolated processes
        const char *nm = env_->GetStringUTFChars(a->nice_name, nullptr);
        if (!nm) return;
        std::string name(nm);
        env_->ReleaseStringUTFChars(a->nice_name, nm);
        // bootanimation is a native binary (never forked from zygote); guard anyway.
        if (name.find("zygote") != std::string::npos || name.find("bootanim") != std::string::npos) return;
        load_cfg(api_->getModuleDir());
        g_tex = g_af || g_bil || g_near || g_lod > 0;
        if (!g_tex && !g_fp16) return;
        std::string pkg = name.substr(0, name.find(':'));
        for (auto &x : g_excl) if (x == pkg) return;
        on_ = true;
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!on_) { api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY); return; }
        patch_all();
    }

    void preServerSpecialize(zygisk::ServerSpecializeArgs *) override {
        api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }
};

REGISTER_ZYGISK_MODULE(GpuMath)
